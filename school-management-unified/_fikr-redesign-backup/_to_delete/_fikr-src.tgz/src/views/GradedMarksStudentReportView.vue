<template>
  <DashboardLayout>
    <div class="space-y-6 pb-10" :dir="isRTL ? 'rtl' : 'ltr'">
      <section class="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-800 via-primary-800 to-teal-800 p-6 text-white shadow-xl sm:p-8">
        <div class="relative flex items-start gap-3">
          <router-link
            to="/reports"
            class="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-md border border-white/30 bg-white/10 text-white hover:bg-white/20 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/50"
            :aria-label="$t('reports.backToReports')"
          >
            <svg class="h-4 w-4 rtl:rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
          </router-link>
          <div>
            <h1 class="text-2xl font-bold tracking-tight sm:text-3xl">{{ $t('reports.gradedStudentTitle') }}</h1>
            <p class="mt-2 max-w-2xl text-sm text-slate-200/95">{{ $t('reports.gradedStudentDesc') }}</p>
          </div>
        </div>
      </section>

      <div class="rounded-2xl border border-gray-200/80 bg-white p-4 shadow-sm sm:p-6">
        <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <div class="sm:col-span-2">
            <label class="mb-1 block text-xs font-semibold text-gray-600">{{ $t('reports.selectStudent') }}</label>
            <select v-model="studentId" class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm">
              <option value="">{{ $t('common.select') }}</option>
              <option v-for="s in students" :key="s.id" :value="s.id">{{ s.name }}</option>
            </select>
          </div>
          <div class="flex items-end">
            <button
              type="button"
              class="inline-flex w-full items-center justify-center rounded-lg bg-primary-600 px-4 py-2 text-sm font-medium text-white hover:bg-primary-700 disabled:opacity-50"
              :disabled="!studentId || loading"
              @click="loadReport"
            >
              {{ loading ? $t('common.loading') : $t('reports.runReport') }}
            </button>
          </div>
        </div>
        <p v-if="error" class="mt-3 text-sm text-red-600">{{ error }}</p>
      </div>

      <div v-if="report" class="space-y-4">
        <div class="rounded-2xl border border-gray-200/80 bg-white px-6 py-4 shadow-sm">
          <h2 class="text-lg font-semibold text-gray-900">{{ report.student_name }}</h2>
          <p class="text-sm text-gray-600">
            {{ $t('reports.coursesWithMarks', { count: report.courses.length }) }}
          </p>
        </div>

        <div
          v-for="course in report.courses"
          :key="course.course_id"
          class="overflow-hidden rounded-2xl border border-gray-200/80 bg-white shadow-sm"
        >
          <div class="flex flex-col gap-2 border-b border-gray-100 bg-gradient-to-r from-primary-50/60 to-white px-6 py-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h3 class="font-semibold text-gray-900">{{ course.course_name }}</h3>
              <p class="text-xs text-gray-500">
                {{ $t('gradedMarksGrid.courseTotalMarks') }}: {{ course.total_marks }}
              </p>
            </div>
            <div class="rounded-xl bg-emerald-50 px-4 py-2 text-center ring-1 ring-emerald-100">
              <div class="text-xs font-medium text-emerald-700">{{ $t('reports.calculatedScore') }}</div>
              <div class="text-lg font-bold tabular-nums text-emerald-900">
                {{ course.course_score }} / {{ course.course_max }}
              </div>
            </div>
          </div>
          <div class="overflow-x-auto">
            <table class="min-w-full text-sm">
              <thead class="bg-gray-50 text-xs text-gray-500">
                <tr>
                  <th class="px-4 py-2 text-start font-semibold">{{ $t('gradedCourses.criteria') }}</th>
                  <th class="px-4 py-2 text-start font-semibold">{{ $t('gradedMarksGrid.semester') }}</th>
                  <th class="px-4 py-2 text-center font-semibold">{{ $t('gradedMarksGrid.mark') }}</th>
                  <th class="px-4 py-2 text-center font-semibold">{{ $t('gradedCourses.pointsShortLabel') }}</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-gray-100">
                <tr v-for="c in course.criteria" :key="c.id">
                  <td class="px-4 py-2 text-gray-900">{{ c.label }}</td>
                  <td class="px-4 py-2 text-gray-600">{{ c.semester_index + 1 }}</td>
                  <td class="px-4 py-2 text-center tabular-nums">{{ c.mark == null ? '—' : c.mark }}</td>
                  <td class="px-4 py-2 text-center tabular-nums text-gray-500">{{ c.max_marks }}</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div v-if="course.semester_scores.length" class="border-t border-gray-100 bg-gray-50/70 px-6 py-3">
            <div class="flex flex-wrap gap-3 text-xs text-gray-700">
              <span
                v-for="sem in course.semester_scores"
                :key="sem.semester_index"
                class="rounded-lg bg-white px-2.5 py-1.5 ring-1 ring-gray-200"
              >
                {{ sem.title || `${$t('gradedMarksGrid.semester')} ${sem.semester_index + 1}` }}:
                <strong class="tabular-nums">{{ sem.score }}/{{ sem.max }}</strong>
              </span>
            </div>
          </div>
        </div>

        <div v-if="!report.courses.length" class="rounded-2xl border border-dashed border-gray-200 py-12 text-center text-sm text-gray-500">
          {{ $t('reports.noGradedMarksYet') }}
        </div>
      </div>
    </div>
  </DashboardLayout>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import DashboardLayout from '@/layouts/DashboardLayout.vue'
import { studentService } from '@/services/student.service'
import authService from '@/services/auth.service'
import gradedCriterionMarksService, {
  type StudentMarksReport,
} from '@/services/graded-criterion-marks.service'

const { locale } = useI18n()
const isRTL = computed(() => locale.value === 'ar')
const schoolId = computed(() => authService.getStoredUser()?.school_id ?? 1)

const students = ref<{ id: string; name: string }[]>([])
const studentId = ref('')
const loading = ref(false)
const error = ref('')
const report = ref<StudentMarksReport | null>(null)

async function loadStudents() {
  const all = await studentService.getAll()
  students.value = all
    .map((s) => ({
      id: s.id,
      name: `${s.firstName || ''} ${s.lastName || ''}`.trim() || s.id,
    }))
    .sort((a, b) => a.name.localeCompare(b.name))
}

async function loadReport() {
  if (!studentId.value) return
  loading.value = true
  error.value = ''
  try {
    report.value = await gradedCriterionMarksService.studentReport({
      schoolId: schoolId.value,
      studentId: studentId.value,
    })
  } catch (e: unknown) {
    report.value = null
    error.value = (e as { message?: string })?.message || 'Failed to load report'
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  void loadStudents()
})
</script>
