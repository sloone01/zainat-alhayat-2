<template>
  <DashboardLayout>
    <div class="space-y-6 pb-10" :dir="isRTL ? 'rtl' : 'ltr'">
      <section class="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-800 via-primary-800 to-teal-800 p-6 text-white shadow-xl sm:p-8">
        <div class="relative flex items-start gap-3">
          <router-link
            to="/reports"
            class="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-md border border-primary-200/80 bg-primary-100 text-primary-700 shadow-sm hover:border-primary-300 hover:bg-primary-200 hover:text-primary-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-500/40 focus-visible:ring-offset-2"
            :aria-label="$t('reports.backToReports')"
          >
            <svg class="h-4 w-4 rtl:rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
          </router-link>
          <div>
            <h1 class="text-2xl font-bold tracking-tight sm:text-3xl">{{ $t('reports.dueFeesTitle') }}</h1>
            <p class="mt-2 max-w-2xl text-sm text-slate-200/95">{{ $t('reports.dueFeesDesc') }}</p>
          </div>
        </div>
      </section>

      <div class="rounded-2xl border border-gray-200/80 bg-white p-4 shadow-sm sm:p-6">
        <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <label class="mb-1 block text-xs font-semibold text-gray-600">{{ $t('reports.asOf') }}</label>
            <input v-model="asOf" type="date" class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" />
          </div>
          <div>
            <label class="mb-1 block text-xs font-semibold text-gray-600">{{ $t('reports.bucket') }}</label>
            <select v-model="bucket" class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm">
              <option value="all">{{ $t('reports.bucket_all') }}</option>
              <option value="late">{{ $t('reports.bucket_late') }}</option>
              <option value="due">{{ $t('reports.bucket_due') }}</option>
              <option value="upcoming">{{ $t('reports.bucket_upcoming') }}</option>
            </select>
          </div>
          <div class="flex items-end sm:col-span-2">
            <button
              type="button"
              class="inline-flex w-full items-center justify-center rounded-lg bg-primary-600 px-4 py-2 text-sm font-medium text-white hover:bg-primary-700 disabled:opacity-50"
              :disabled="loading"
              @click="loadReport"
            >
              {{ loading ? $t('common.loading') : $t('reports.runReport') }}
            </button>
          </div>
        </div>
        <p v-if="error" class="mt-3 text-sm text-red-600">{{ error }}</p>
      </div>

      <div v-if="report" class="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <div class="rounded-xl border border-red-200 bg-red-50 p-4">
          <p class="text-xs text-red-800">{{ $t('reports.bucket_late') }}</p>
          <p class="text-xl font-bold tabular-nums text-red-950">{{ report.summary.late }}</p>
        </div>
        <div class="rounded-xl border border-amber-200 bg-amber-50 p-4">
          <p class="text-xs text-amber-800">{{ $t('reports.bucket_due') }}</p>
          <p class="text-xl font-bold tabular-nums text-amber-950">{{ report.summary.due }}</p>
        </div>
        <div class="rounded-xl border border-sky-200 bg-sky-50 p-4">
          <p class="text-xs text-sky-800">{{ $t('reports.bucket_upcoming') }}</p>
          <p class="text-xl font-bold tabular-nums text-sky-950">{{ report.summary.upcoming }}</p>
        </div>
        <div class="rounded-xl border border-gray-200 bg-white p-4">
          <p class="text-xs text-gray-600">{{ $t('reports.balanceTotal') }}</p>
          <p class="text-xl font-bold tabular-nums text-gray-900">{{ fmt(report.summary.balance_total) }}</p>
        </div>
      </div>

      <div v-if="report" class="overflow-hidden rounded-2xl border border-gray-200/80 bg-white shadow-sm">
        <div v-if="!report.items.length" class="px-6 py-16 text-center text-sm text-gray-500">
          {{ $t('reports.dueFeesEmpty') }}
        </div>
        <div v-else class="overflow-x-auto">
          <table class="min-w-full text-sm">
            <thead class="bg-gray-50 text-xs uppercase tracking-wide text-gray-500">
              <tr>
                <th class="px-4 py-3 text-start font-semibold">{{ $t('progressTracking.studentName') }}</th>
                <th class="px-4 py-3 text-start font-semibold">{{ $t('feesV2.installment') }}</th>
                <th class="px-4 py-3 text-start font-semibold">{{ $t('feesV2.dueOn') }}</th>
                <th class="px-4 py-3 text-end font-semibold">{{ $t('feesV2.due') }}</th>
                <th class="px-4 py-3 text-end font-semibold">{{ $t('feesV2.paid') }}</th>
                <th class="px-4 py-3 text-end font-semibold">{{ $t('reports.balance') }}</th>
                <th class="px-4 py-3 text-end font-semibold">{{ $t('feesV2.status') }}</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
              <tr v-for="row in report.items" :key="row.installment_id" class="hover:bg-gray-50">
                <td class="px-4 py-3 font-medium text-gray-900">{{ row.student_name }}</td>
                <td class="px-4 py-3 text-gray-700">
                  {{ row.label || `${$t('feesV2.installment')} ${row.sequence}` }}
                </td>
                <td class="px-4 py-3 tabular-nums text-gray-700">{{ row.due_date || '—' }}</td>
                <td class="px-4 py-3 text-end tabular-nums">{{ fmt(row.amount_due) }}</td>
                <td class="px-4 py-3 text-end tabular-nums">{{ fmt(row.amount_paid) }}</td>
                <td class="px-4 py-3 text-end font-semibold tabular-nums">{{ fmt(row.balance) }}</td>
                <td class="px-4 py-3 text-end">
                  <span class="rounded-full px-2 py-0.5 text-xs font-semibold" :class="stateClass(row.state)">
                    {{ $t(`reports.state_${row.state}`) }}
                    <template v-if="row.state === 'late' && row.days_overdue">
                      · {{ $t('reports.daysOverdue', { n: row.days_overdue }) }}
                    </template>
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </DashboardLayout>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import DashboardLayout from '@/layouts/DashboardLayout.vue'
import { feesV2Service, type DueInstallmentsReport } from '@/services/fees-v2.service'

const { locale, t } = useI18n()
const isRTL = computed(() => locale.value === 'ar')
const asOf = ref(new Date().toISOString().slice(0, 10))
const bucket = ref<'all' | 'due' | 'late' | 'upcoming'>('all')
const loading = ref(false)
const error = ref('')
const report = ref<DueInstallmentsReport | null>(null)

function fmt(v: string | number) {
  return Number(v || 0).toFixed(3)
}

function stateClass(state: string) {
  if (state === 'late') return 'bg-red-100 text-red-800'
  if (state === 'due') return 'bg-amber-100 text-amber-800'
  if (state === 'upcoming') return 'bg-sky-100 text-sky-800'
  return 'bg-gray-100 text-gray-700'
}

async function loadReport() {
  loading.value = true
  error.value = ''
  try {
    report.value = await feesV2Service.dueInstallmentsReport({
      as_of: asOf.value,
      bucket: bucket.value,
    })
  } catch (e: unknown) {
    report.value = null
    error.value = (e as { message?: string })?.message || t('reports.dueFeesLoadError')
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  void loadReport()
})
</script>
