<template>
  <DashboardLayout>
    <div class="space-y-6 pb-10" :dir="isRTL ? 'rtl' : 'ltr'">
      <section class="relative overflow-hidden rounded-2xl bg-gradient-to-br from-amber-700 via-amber-600 to-orange-500 p-6 text-white shadow-xl sm:p-8">
        <div class="relative flex items-start gap-3">
          <router-link
            to="/students/payments"
            class="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-md border border-white/30 bg-white/10 text-white hover:bg-white/20 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/50"
            :aria-label="$t('feesV2.backToStudentCharges')"
          >
            <svg class="h-4 w-4 rtl:rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
          </router-link>
          <div>
            <h1 class="text-2xl font-bold tracking-tight sm:text-3xl">{{ $t('feesV2.pendingApprovals') }}</h1>
            <p class="mt-2 max-w-2xl text-sm text-amber-50/95">{{ $t('feesV2.pendingApprovalsSchoolHint') }}</p>
          </div>
        </div>
      </section>

      <div v-if="loading" class="flex flex-col items-center justify-center gap-3 py-20 text-gray-500">
        <span class="h-10 w-10 animate-spin rounded-full border-2 border-amber-500 border-t-transparent" />
        <span class="text-sm">{{ $t('common.loading') }}</span>
      </div>

      <div
        v-else-if="!payments.length"
        class="rounded-2xl border border-dashed border-gray-200 bg-white py-16 text-center text-sm text-gray-500 shadow-sm"
      >
        {{ $t('feesV2.pendingApprovalsEmpty') }}
      </div>

      <div v-else class="overflow-hidden rounded-2xl border border-amber-200/80 bg-white shadow-sm">
        <div class="border-b border-amber-100 bg-amber-50/60 px-6 py-3 text-xs font-medium text-amber-900">
          {{ $t('feesV2.pendingApprovalsCount', { count: payments.length }) }}
        </div>
        <ul class="divide-y divide-gray-100">
          <li
            v-for="p in payments"
            :key="p.id"
            class="flex flex-wrap items-center justify-between gap-3 px-6 py-4"
          >
            <div class="min-w-0">
              <p class="font-medium text-gray-900">
                {{ p.student ? `${p.student.firstName} ${p.student.lastName}` : p.student_id }}
                · {{ fmt(p.amount) }} OMR
              </p>
              <p class="mt-0.5 text-xs text-gray-500">
                {{ $t(`parentFees.method_${p.method}`) }}
                <span v-if="p.remarks"> · {{ p.remarks }}</span>
              </p>
              <a
                v-if="p.proof_url"
                :href="proofHref(p.proof_url)"
                target="_blank"
                rel="noopener"
                class="mt-1 inline-block text-xs font-medium text-teal-700 hover:underline"
              >
                {{ $t('feesV2.viewReceipt') }}
              </a>
            </div>
            <span
              class="rounded-full px-2.5 py-0.5 text-xs font-semibold"
              :class="p.status === 'pending_reconcile' ? 'bg-sky-100 text-sky-800' : 'bg-amber-100 text-amber-800'"
            >
              {{ $t(`parentFees.status_${p.status}`) }}
            </span>
          </li>
        </ul>
      </div>
    </div>
  </DashboardLayout>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import DashboardLayout from '@/layouts/DashboardLayout.vue'
import { feesV2Service, type FeePayment } from '@/services/fees-v2.service'
import { mediaUrl } from '@/utils/thawaniCheckout'

const { locale } = useI18n()
const isRTL = computed(() => locale.value === 'ar')

const payments = ref<FeePayment[]>([])
const loading = ref(true)

function fmt(v: string | number) {
  return Number(v || 0).toFixed(3)
}

function proofHref(url: string) {
  return mediaUrl(url)
}

onMounted(async () => {
  loading.value = true
  try {
    payments.value = await feesV2Service.listPendingPayments()
  } catch {
    payments.value = []
  } finally {
    loading.value = false
  }
})
</script>
