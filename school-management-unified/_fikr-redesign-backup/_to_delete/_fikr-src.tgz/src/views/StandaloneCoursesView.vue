<template>
  <DashboardLayout>
    <div class="space-y-6 pb-10" :dir="isRTL ? 'rtl' : 'ltr'">
      <section class="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-800 via-primary-800 to-teal-800 p-6 text-white shadow-xl sm:p-8">
        <div class="relative">
          <h1 class="text-2xl font-bold tracking-tight sm:text-3xl">{{ $t('standaloneCourses.title') }}</h1>
          <p class="mt-2 max-w-2xl text-sm text-slate-200/95">{{ $t('standaloneCourses.subtitle') }}</p>
        </div>
      </section>

      <div class="rounded-2xl border border-gray-200/80 bg-white p-4 shadow-sm sm:p-6">
        <h2 class="text-sm font-semibold text-gray-900">{{ $t('standaloneCourses.addHeading') }}</h2>
        <form class="mt-4 grid gap-3 sm:grid-cols-2" @submit.prevent="createCourse">
          <div>
            <label class="mb-1 block text-xs font-medium text-gray-600">{{ $t('standaloneCourses.name') }} *</label>
            <input v-model="name" required class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" />
          </div>
          <div>
            <label class="mb-1 block text-xs font-medium text-gray-600">{{ $t('standaloneCourses.description') }}</label>
            <input v-model="description" class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" />
          </div>
          <div class="sm:col-span-2">
            <button
              type="submit"
              class="rounded-lg bg-primary-600 px-4 py-2 text-sm font-medium text-white hover:bg-primary-700 disabled:opacity-50"
              :disabled="saving"
            >
              {{ saving ? $t('common.saving') : $t('standaloneCourses.create') }}
            </button>
            <p v-if="error" class="mt-2 text-sm text-red-600">{{ error }}</p>
          </div>
        </form>
      </div>

      <div class="overflow-hidden rounded-2xl border border-gray-200/80 bg-white shadow-sm">
        <div class="border-b border-gray-100 px-6 py-4">
          <h2 class="text-lg font-semibold text-gray-900">{{ $t('standaloneCourses.listHeading') }}</h2>
        </div>
        <div v-if="loading" class="flex justify-center py-12">
          <span class="h-10 w-10 animate-spin rounded-full border-2 border-primary-500 border-t-transparent" />
        </div>
        <div v-else-if="!courses.length" class="py-12 text-center text-sm text-gray-500">
          {{ $t('standaloneCourses.empty') }}
        </div>
        <ul v-else class="divide-y divide-gray-100">
          <li v-for="c in courses" :key="c.id" class="flex items-center justify-between gap-3 px-6 py-4">
            <div>
              <div class="font-medium text-gray-900">{{ c.name || c.title }}</div>
              <div v-if="c.description" class="text-xs text-gray-500">{{ c.description }}</div>
            </div>
            <router-link
              :to="{ path: '/course-materials', query: { course: c.id } }"
              class="text-sm font-semibold text-primary-700 hover:text-primary-900"
            >
              {{ $t('courseMaterials.navTitle') }}
            </router-link>
          </li>
        </ul>
      </div>
    </div>
  </DashboardLayout>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import DashboardLayout from '@/layouts/DashboardLayout.vue'
import authService from '@/services/auth.service'
import courseService, { type Course } from '@/services/course.service'

const { locale } = useI18n()
const isRTL = computed(() => locale.value === 'ar')
const schoolId = computed(() => authService.getStoredUser()?.school_id ?? 1)

const courses = ref<Course[]>([])
const loading = ref(false)
const name = ref('')
const description = ref('')
const saving = ref(false)
const error = ref('')

async function load() {
  loading.value = true
  try {
    courses.value = await courseService.getAllCourses(schoolId.value, 'standalone')
  } catch {
    courses.value = []
  } finally {
    loading.value = false
  }
}

async function createCourse() {
  saving.value = true
  error.value = ''
  try {
    await courseService.createCourse({
      name: name.value.trim(),
      title: name.value.trim(),
      description: description.value.trim() || undefined,
      school_id: schoolId.value,
      course_kind: 'standalone',
      status: 'active',
      is_active: true,
      category: 'standalone',
    })
    name.value = ''
    description.value = ''
    await load()
  } catch (e: unknown) {
    error.value = (e as { message?: string })?.message || 'Failed'
  } finally {
    saving.value = false
  }
}

onMounted(() => {
  void load()
})
</script>
