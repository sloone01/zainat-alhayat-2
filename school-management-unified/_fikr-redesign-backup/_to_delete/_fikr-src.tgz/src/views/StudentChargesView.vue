<template>
  <DashboardLayout>
    <div class="min-w-0 space-y-3 overflow-x-hidden pb-6 sm:space-y-4 sm:pb-10" :dir="isRTL ? 'rtl' : 'ltr'">
      <section
        class="rounded-2xl bg-gradient-to-r from-primary-700 to-teal-600 p-3 text-white shadow-lg sm:p-6"
        :class="selectedId ? 'hidden lg:block' : ''"
      >
        <h1 class="text-lg font-bold sm:text-2xl">{{ $t('feesV2.studentChargesTitle') }}</h1>
        <p class="mt-1 text-xs text-primary-50/95 sm:text-sm">{{ $t('feesV2.studentChargesSubtitle') }}</p>
      </section>

      <div class="grid min-w-0 grid-cols-1 gap-4 lg:grid-cols-3">
        <div
          class="flex max-h-[calc(100dvh-11.5rem)] flex-col overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm lg:max-h-none lg:col-span-1"
          :class="selectedId ? 'hidden lg:block' : ''"
        >
          <div class="shrink-0 border-b border-gray-100 p-4">
            <input v-model="search" type="search" :placeholder="$t('studentPayments.searchPlaceholder')" class="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm" />
          </div>
          <div v-if="loadingList" class="flex flex-1 flex-col items-center justify-center py-16 text-gray-500">
            <span class="h-8 w-8 animate-spin rounded-full border-2 border-primary-200 border-t-primary-600" aria-hidden="true" />
            <span class="mt-2 text-sm">{{ $t('common.loading') }}</span>
          </div>
          <div v-else-if="listError" class="flex-1 px-4 py-8 text-center text-sm text-red-700">{{ listError }}</div>
          <div v-else-if="!filteredStudents.length" class="flex-1 px-4 py-10 text-center">
            <p class="text-sm font-medium text-gray-700">{{ $t('studentPayments.noStudents') }}</p>
            <p v-if="search.trim()" class="mt-1 text-xs text-gray-500">{{ $t('studentPayments.tryClearSearch') }}</p>
          </div>
          <ul v-else class="min-h-0 flex-1 divide-y divide-gray-50 overflow-y-auto lg:max-h-[28rem]">
            <li v-for="s in filteredStudents" :key="s.id">
              <button
                type="button"
                @click="selectStudent(s)"
                :class="[
                  'w-full text-start px-4 py-3 transition-colors',
                  selectedId === s.id
                    ? 'bg-primary-50 border-s-4 border-primary-500'
                    : 'hover:bg-gray-50',
                ]"
              >
                <div class="font-medium text-gray-900">
                  {{ s.firstName }} {{ s.lastName }}
                </div>
                <span
                  v-if="!studentHasFeeLevel(s)"
                  class="mt-1 inline-flex items-center rounded-full bg-red-600 px-2 py-0.5 text-[11px] font-semibold leading-none text-white"
                >
                  {{ $t('feesV2.noGrade') }}
                </span>
                <div v-else class="mt-0.5 text-xs text-gray-500">
                  {{ gradeLabel(s) }}
                </div>
              </button>
            </li>
          </ul>
        </div>

        <div class="min-w-0 space-y-4 lg:col-span-2" :class="selectedId ? '' : 'hidden lg:block'">
          <div v-if="!selectedId" class="rounded-2xl border border-dashed border-gray-200 bg-gray-50/50 p-8 text-center text-sm text-gray-500 sm:p-12">
            {{ $t('feesV2.selectStudent') }}
          </div>

          <template v-else>
            <div class="flex items-center gap-3 lg:hidden">
              <button
                type="button"
                class="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-md border border-primary-200/80 bg-primary-100 text-primary-700 shadow-sm hover:border-primary-300 hover:bg-primary-200 hover:text-primary-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-500/40 focus-visible:ring-offset-2"
                :aria-label="$t('feesV2.backToStudents')"
                @click="clearSelection"
              >
                <svg class="h-4 w-4 rtl:rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <div class="min-w-0">
                <p class="truncate text-sm font-semibold text-gray-900">
                  {{ selectedStudent ? `${selectedStudent.firstName} ${selectedStudent.lastName}` : '' }}
                </p>
                <span
                  v-if="selectedStudent && !studentHasFeeLevel(selectedStudent)"
                  class="mt-0.5 inline-flex items-center rounded-full bg-red-600 px-2 py-0.5 text-[11px] font-semibold leading-none text-white"
                >
                  {{ $t('feesV2.noGrade') }}
                </span>
                <p v-else-if="selectedStudent" class="truncate text-xs text-gray-500">
                  {{ gradeLabel(selectedStudent) }}
                </p>
              </div>
            </div>

            <div v-if="loadingSheet" class="flex flex-col items-center justify-center py-16 text-gray-500">
              <span class="h-8 w-8 animate-spin rounded-full border-2 border-primary-200 border-t-primary-600" aria-hidden="true" />
            </div>
            <div v-else-if="!sheet" class="py-8 text-center sm:py-12">
              <p class="text-sm font-medium text-gray-800">{{ sheetEmptyTitle }}</p>
              <p class="mx-auto mt-1 max-w-md text-sm text-gray-500">{{ sheetEmptyBody }}</p>
              <button
                v-if="sheetReason === 'generic'"
                type="button"
                class="mt-3 text-sm font-medium text-primary-700 hover:text-primary-800"
                @click="refreshSheet"
              >
                {{ $t('feesV2.refreshCharges') }}
              </button>
            </div>
            <template v-else-if="sheet">
              <div class="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-5">
                <div class="min-w-0 rounded-xl border border-gray-200 bg-white p-3 shadow-sm sm:p-4">
                  <p class="text-xs text-gray-500">{{ $t('feesV2.totalList') }}</p>
                  <p class="text-base font-bold tabular-nums text-gray-900 sm:text-lg">{{ fmt(sheet.list_total) }}</p>
                </div>
                <div class="min-w-0 rounded-xl border border-violet-200/80 bg-violet-50 p-3 sm:p-4">
                  <p class="text-xs text-violet-800">{{ $t('feesV2.discounts') }}</p>
                  <p class="text-base font-bold tabular-nums text-violet-900 sm:text-lg">−{{ fmt(sheet.discount_total) }}</p>
                </div>
                <div class="min-w-0 rounded-xl border border-amber-200/80 bg-amber-50 p-3 sm:p-4">
                  <p class="text-xs text-amber-800">{{ $t('feesV2.upfrontDue') }}</p>
                  <p class="text-base font-bold tabular-nums text-amber-900 sm:text-lg">{{ fmt(sheet.upfront_due) }}</p>
                </div>
                <div class="min-w-0 rounded-xl border border-sky-200/80 bg-sky-50 p-3 sm:p-4">
                  <p class="text-xs text-sky-800">{{ $t('feesV2.installmentDue') }}</p>
                  <p class="text-base font-bold tabular-nums text-sky-900 sm:text-lg">{{ fmt(sheet.installment_due) }}</p>
                </div>
                <div class="min-w-0 rounded-xl border border-emerald-200/80 bg-emerald-50 p-3 sm:p-4">
                  <p class="text-xs text-emerald-800">{{ $t('feesV2.paid') }}</p>
                  <p class="text-base font-bold tabular-nums text-emerald-900 sm:text-lg">{{ fmt(sheet.paid_total) }}</p>
                </div>
              </div>

              <div class="flex flex-col gap-3 rounded-2xl border border-gray-200 bg-white p-4 shadow-sm sm:flex-row sm:flex-wrap sm:items-end">
                <div class="min-w-0 w-full sm:min-w-[200px] sm:flex-1">
                  <label class="mb-1 block text-xs font-medium text-gray-600">{{ $t('feesV2.installmentPlan') }}</label>
                  <select v-model="selectedPlanId" class="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm">
                    <option value="">{{ $t('feesV2.noPlan') }}</option>
                    <option v-for="p in plans" :key="p.id" :value="p.id">{{ p.name }}</option>
                  </select>
                </div>
                <button type="button" class="w-full rounded-lg bg-primary-600 px-4 py-2 text-sm font-semibold text-white hover:bg-primary-700 sm:w-auto" @click="applyPlan">
                  {{ $t('feesV2.applyPlan') }}
                </button>
                <button type="button" class="w-full rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 sm:w-auto" @click="refreshSheet">
                  {{ $t('feesV2.refreshCharges') }}
                </button>
                <button
                  v-if="Number(sheet.upfront_due) > 0"
                  type="button"
                  :disabled="hasOpenUpfront || paying"
                  class="w-full rounded-lg bg-amber-600 px-4 py-2 text-sm font-semibold text-white hover:bg-amber-700 disabled:opacity-50 sm:w-auto"
                  @click="openPay('upfront')"
                >
                  {{ hasOpenUpfront ? $t('parentFees.waitingApproval') : $t('feesV2.payUpfront') }}
                </button>
              </div>

              <!-- Discounts -->
              <div class="rounded-2xl border border-gray-200 bg-white overflow-hidden shadow-sm">
                <div class="px-5 py-3 border-b border-gray-100 bg-violet-50/50 flex items-center justify-between">
                  <h2 class="text-sm font-semibold text-violet-900">{{ $t('feesV2.discounts') }}</h2>
                  <button type="button" @click="addDiscountRow" class="text-xs font-medium text-violet-700 hover:text-violet-900">+ {{ $t('feesV2.addDiscount') }}</button>
                </div>
                <div v-if="!discountRows.length" class="px-5 py-4 text-sm text-gray-500">{{ $t('feesV2.noDiscounts') }}</div>
                <div v-else class="divide-y divide-gray-100">
                  <div v-for="(row, idx) in discountRows" :key="idx" class="flex flex-wrap items-center gap-3 px-4 py-3 sm:px-5">
                    <select v-model="row.discount_type_id" class="min-w-0 flex-1 basis-full rounded-lg border border-gray-200 px-3 py-1.5 text-sm sm:basis-auto sm:min-w-[160px]">
                      <option value="">{{ $t('feesV2.chooseDiscount') }}</option>
                      <option v-for="d in discountTypes" :key="d.id" :value="d.id">{{ d.label }}</option>
                    </select>
                    <input v-model.number="row.amount" type="number" min="0" step="0.001" dir="ltr" class="w-28 rounded-lg border border-gray-200 px-3 py-1.5 text-end font-mono text-sm" />
                    <button type="button" @click="discountRows.splice(idx, 1)" class="text-red-600 text-xs font-medium hover:text-red-800">{{ $t('common.delete') }}</button>
                  </div>
                </div>
                <div v-if="discountRows.length" class="px-5 py-3 border-t border-gray-100 flex justify-end">
                  <button type="button" @click="saveDiscounts" :disabled="savingDiscounts" class="rounded-lg bg-violet-600 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-700 disabled:opacity-50">
                    {{ $t('feesV2.saveDiscounts') }}
                  </button>
                </div>
              </div>

              <div class="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">
                <div class="border-b border-gray-100 bg-gray-50/80 px-4 py-3 sm:px-5">
                  <h2 class="text-sm font-semibold text-gray-900">{{ $t('feesV2.chargeLines') }}</h2>
                </div>
                <div class="overflow-x-auto">
                  <table class="min-w-full text-sm">
                    <thead class="bg-gray-50 text-xs uppercase text-gray-500">
                      <tr>
                        <th class="px-4 py-2 text-start sm:px-5">{{ $t('feesV2.charge') }}</th>
                        <th class="px-3 py-2 text-end">{{ $t('feesV2.list') }}</th>
                        <th class="px-3 py-2 text-end">{{ $t('feesV2.due') }}</th>
                        <th class="px-4 py-2 text-end sm:px-5">{{ $t('feesV2.status') }}</th>
                      </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                      <tr v-for="line in sheet.lines" :key="line.id" class="hover:bg-gray-50/50">
                        <td class="px-4 py-3 sm:px-5">
                          <div class="font-medium text-gray-900">{{ line.charge_label }}</div>
                          <div class="mt-0.5 text-[10px] uppercase text-gray-400">{{ line.source_type }}</div>
                        </td>
                        <td class="px-3 py-3 text-end font-mono tabular-nums text-gray-600">{{ fmt(line.list_amount) }}</td>
                        <td class="px-3 py-3 text-end font-mono text-sm font-semibold tabular-nums text-gray-900">{{ fmt(line.due_amount) }}</td>
                        <td class="px-4 py-3 text-end sm:px-5">
                          <span :class="statusClass(line.status)" class="inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold">
                            {{ $t(`feesV2.status_${line.status}`) }}
                          </span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <div v-if="sheet.installments?.length" class="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">
                <div class="border-b border-gray-100 px-4 py-3 sm:px-5">
                  <h2 class="text-sm font-semibold text-gray-900">{{ $t('feesV2.schedule') }}</h2>
                </div>
                <div class="divide-y divide-gray-100">
                  <div v-for="inst in sheet.installments" :key="inst.id" class="flex flex-col gap-3 px-4 py-3 sm:flex-row sm:items-center sm:justify-between sm:px-5">
                    <div class="min-w-0">
                      <span class="font-medium text-gray-900">{{ inst.label || `${$t('feesV2.installment')} ${inst.sequence}` }}</span>
                      <span v-if="inst.due_date" class="ms-2 text-xs text-gray-500">· {{ $t('feesV2.dueOn') }} {{ inst.due_date }}</span>
                      <span v-else-if="inst.month_number" class="ms-2 text-xs text-gray-500">· {{ $t('feesV2.month') }} {{ inst.month_number }}</span>
                    </div>
                    <div class="flex items-center justify-between gap-3 sm:justify-end">
                      <div class="text-end">
                        <div class="font-mono font-semibold tabular-nums">{{ fmt(inst.amount_paid) }} / {{ fmt(inst.amount_due) }}</div>
                        <span :class="statusClass(inst.status)" class="text-xs font-medium">{{ $t(`feesV2.status_${inst.status}`) }}</span>
                      </div>
                      <button
                        v-if="inst.status !== 'paid'"
                        type="button"
                        :disabled="hasOpenInstallment(inst.id) || paying"
                        class="shrink-0 rounded-lg bg-primary-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-primary-700 disabled:opacity-50"
                        @click="openPay('installment', inst)"
                      >
                        {{ hasOpenInstallment(inst.id) ? $t('parentFees.waitingApproval') : $t('feesV2.pay') }}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div v-if="studentPayments.length" class="rounded-2xl border border-gray-200 bg-white overflow-hidden shadow-sm">
                <div class="px-5 py-3 border-b border-gray-100 bg-gray-50/80">
                  <h2 class="text-sm font-semibold text-gray-900">{{ $t('parentFees.paymentHistory') }}</h2>
                </div>
                <ul class="divide-y divide-gray-100">
                  <li v-for="p in studentPayments" :key="p.id" class="flex flex-wrap items-center justify-between gap-2 px-5 py-3 text-sm">
                    <div>
                      <p class="font-medium text-gray-900">{{ fmt(p.amount) }} OMR · {{ $t(`parentFees.method_${p.method}`) }}</p>
                      <p class="text-xs text-gray-500">{{ p.remarks || p.review_notes || '' }}</p>
                      <a
                        v-if="p.proof_url"
                        :href="mediaUrl(p.proof_url)"
                        target="_blank"
                        rel="noopener"
                        class="mt-1 inline-block text-xs font-medium text-teal-700 hover:underline"
                      >
                        {{ $t('feesV2.viewReceipt') }}
                      </a>
                    </div>
                    <span
                      class="rounded-full px-2 py-0.5 text-xs font-semibold"
                      :class="schoolPayStatusClass(p.status)"
                    >
                      {{ $t(`parentFees.status_${p.status}`) }}
                    </span>
                  </li>
                </ul>
              </div>
            </template>
          </template>
        </div>
      </div>
    </div>

    <div v-if="payTarget" class="fixed inset-0 z-50 flex items-end justify-center p-4 sm:items-center">
      <div class="absolute inset-0 bg-gray-900/45" @click="closePay" />
      <div class="relative max-h-[90dvh] w-full max-w-lg overflow-y-auto rounded-2xl bg-white p-5 shadow-xl sm:p-6" :dir="isRTL ? 'rtl' : 'ltr'">
        <h2 class="text-lg font-bold text-gray-900">{{ $t('feesV2.schoolPayTitle') }}</h2>
        <p class="mt-1 text-sm text-gray-600">{{ $t('feesV2.schoolPayHint') }}</p>
        <p class="mt-3 text-2xl font-extrabold tabular-nums text-teal-800">{{ fmt(payAmount) }} OMR</p>
        <div class="mt-4 space-y-3">
          <label class="block text-xs font-medium text-gray-600">{{ $t('parentFees.attachReceipt') }}</label>
          <input type="file" accept="image/jpeg,image/png,image/webp,application/pdf" class="block w-full text-sm" @change="onProofPicked" />
          <textarea
            v-model="payRemarks"
            rows="2"
            class="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm"
            :placeholder="$t('parentFees.remarksPlaceholder')"
          />
        </div>
        <p v-if="payError" class="mt-3 text-sm text-red-700">{{ payError }}</p>
        <div class="mt-6 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
          <button type="button" class="w-full rounded-lg border border-gray-200 px-4 py-2 text-sm font-medium text-gray-700 sm:w-auto" @click="closePay">
            {{ $t('common.cancel') }}
          </button>
          <button
            type="button"
            class="w-full rounded-lg bg-teal-600 px-4 py-2 text-sm font-semibold text-white hover:bg-teal-700 disabled:opacity-50 sm:w-auto"
            :disabled="paying || !proofFile"
            @click="submitPay"
          >
            {{ paying ? $t('common.loading') : $t('parentFees.confirmPay') }}
          </button>
        </div>
      </div>
    </div>
  </DashboardLayout>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import DashboardLayout from '@/layouts/DashboardLayout.vue'
import { studentService, type Student } from '@/services'
import { feesV2Service, type FeePayment, type StudentChargeSheet, type InstallmentPlan } from '@/services/fees-v2.service'
import { mediaUrl } from '@/utils/thawaniCheckout'
import paymentConfigService, { type PaymentCatalogRow } from '@/services/payment-config.service'
import { authService } from '@/services'

const { locale, t } = useI18n()
const isRTL = computed(() => locale.value === 'ar')

const students = ref<Student[]>([])
const search = ref('')
const selectedId = ref<string | null>(null)
const sheet = ref<StudentChargeSheet | null>(null)
const loadingSheet = ref(false)
const loadingList = ref(true)
const listError = ref('')
const plans = ref<InstallmentPlan[]>([])
const selectedPlanId = ref('')
const discountTypes = ref<PaymentCatalogRow[]>([])
const discountRows = ref<Array<{ discount_type_id: string; amount: number }>>([])
const savingDiscounts = ref(false)
const studentPayments = ref<FeePayment[]>([])
const payTarget = ref<'upfront' | 'installment' | null>(null)
const payInstallmentId = ref<string | null>(null)
const payAmount = ref(0)
const payRemarks = ref('')
const proofFile = ref<File | null>(null)
const paying = ref(false)
const payError = ref('')
const sheetReason = ref<'no_grade' | 'no_year' | 'generic' | ''>('')

function isOpenPaymentStatus(status: string) {
  return status === 'pending' || status === 'pending_approval' || status === 'pending_reconcile'
}

const hasOpenUpfront = computed(() =>
  studentPayments.value.some((p) => p.target_type === 'upfront' && isOpenPaymentStatus(p.status)),
)

function hasOpenInstallment(id: string) {
  return studentPayments.value.some((p) => p.installment_id === id && isOpenPaymentStatus(p.status))
}

const schoolId = computed(() => authService.getStoredUser()?.school_id ?? 1)

const filteredStudents = computed(() => {
  const q = search.value.trim().toLowerCase()
  if (!q) return students.value
  return students.value.filter((s) => `${s.firstName} ${s.lastName}`.toLowerCase().includes(q))
})

const selectedStudent = computed(() =>
  students.value.find((s) => s.id === selectedId.value) ?? null,
)

const sheetEmptyTitle = computed(() => {
  if (sheetReason.value === 'no_grade') return t('feesV2.needGradeTitle')
  if (sheetReason.value === 'no_year') return t('feesV2.needYearTitle')
  return t('feesV2.sheetUnavailable')
})

const sheetEmptyBody = computed(() => {
  if (sheetReason.value === 'no_grade') return t('feesV2.needGradeBody')
  if (sheetReason.value === 'no_year') return t('feesV2.needYearBody')
  return t('feesV2.sheetUnavailable')
})

function studentHasFeeLevel(s: Student) {
  if (s.payment_level_id || s.paymentLevel?.id) return true
  const groups = s.groups as Array<{ level_id?: string | null; level?: { id?: string } }> | undefined
  return Boolean(groups?.some((g) => g.level_id || g.level?.id))
}

function classifySheetError(e: unknown): 'no_grade' | 'no_year' | 'generic' {
  const data = (e as { response?: { data?: Record<string, unknown> } })?.response?.data
  const nested = data?.message
  const code =
    (typeof data?.code === 'string' && data.code) ||
    (nested && typeof nested === 'object' && nested !== null && 'code' in nested
      ? String((nested as { code?: string }).code || '')
      : '')
  if (code === 'STUDENT_NO_GRADE') return 'no_grade'
  if (code === 'NO_ACTIVE_YEAR') return 'no_year'
  const msg = Array.isArray(nested)
    ? nested.join(' ')
    : typeof nested === 'string'
      ? nested
      : nested && typeof nested === 'object' && 'message' in nested
        ? String((nested as { message?: string }).message || '')
        : ''
  if (/grade/i.test(msg)) return 'no_grade'
  if (/academic year/i.test(msg)) return 'no_year'
  return 'generic'
}

function clearSelection() {
  selectedId.value = null
  sheet.value = null
  sheetReason.value = ''
}

function fmt(v: string | number) {
  return Number(v || 0).toFixed(3)
}

function gradeLabel(s: Student) {
  const pl = (s as Student & { paymentLevel?: { name?: string } }).paymentLevel
  return pl?.name || ''
}

function statusClass(status: string) {
  if (status === 'paid') return 'bg-emerald-100 text-emerald-800'
  if (status === 'partial') return 'bg-amber-100 text-amber-800'
  if (status === 'waived') return 'bg-gray-100 text-gray-600'
  return 'bg-sky-100 text-sky-800'
}

function schoolPayStatusClass(status: string) {
  if (status === 'paid') return 'bg-emerald-100 text-emerald-800'
  if (status === 'pending_reconcile') return 'bg-sky-100 text-sky-800'
  if (status === 'pending_approval' || status === 'pending') return 'bg-amber-100 text-amber-800'
  if (status === 'rejected' || status === 'failed' || status === 'cancelled') return 'bg-red-100 text-red-800'
  return 'bg-gray-100 text-gray-700'
}

function syncDiscountRows() {
  discountRows.value = (sheet.value?.discountLines || []).map((d) => ({
    discount_type_id: d.discount_type_id,
    amount: Number(d.amount) || 0,
  }))
}

async function loadStudents() {
  loadingList.value = true
  listError.value = ''
  try {
    const sid = Number(schoolId.value)
    const rows = await studentService.getAll()
    students.value = rows.filter((s) => s.school_id == null || Number(s.school_id) === sid)
  } catch (e: unknown) {
    students.value = []
    const err = e as { message?: string }
    listError.value = err?.message || t('studentPayments.loadError')
  } finally {
    loadingList.value = false
  }
}

async function selectStudent(s: Student) {
  selectedId.value = s.id
  if (!studentHasFeeLevel(s)) {
    sheet.value = null
    sheetReason.value = 'no_grade'
    studentPayments.value = []
    loadingSheet.value = false
    return
  }
  sheet.value = null
  sheetReason.value = ''
  loadingSheet.value = true
  try {
    sheet.value = await feesV2Service.getStudentChargeSheet(s.id)
    studentPayments.value = await feesV2Service.listStudentPayments(s.id).catch(() => [])
    selectedPlanId.value = sheet.value.installment_plan_id || ''
    syncDiscountRows()
  } catch (e: unknown) {
    sheet.value = null
    sheetReason.value = classifySheetError(e)
  } finally {
    loadingSheet.value = false
  }
}

async function refreshSheet() {
  if (!selectedId.value) return
  const current = selectedStudent.value
  if (current && !studentHasFeeLevel(current)) {
    sheet.value = null
    sheetReason.value = 'no_grade'
    return
  }
  loadingSheet.value = true
  sheetReason.value = ''
  try {
    sheet.value = await feesV2Service.refreshStudentChargeSheet(selectedId.value)
    selectedPlanId.value = sheet.value.installment_plan_id || ''
    syncDiscountRows()
  } catch (e: unknown) {
    sheet.value = null
    sheetReason.value = classifySheetError(e)
  } finally {
    loadingSheet.value = false
  }
}

async function applyPlan() {
  if (!selectedId.value) return
  sheet.value = await feesV2Service.assignInstallmentPlan(selectedId.value, selectedPlanId.value || null)
  syncDiscountRows()
}

function addDiscountRow() {
  discountRows.value.push({ discount_type_id: '', amount: 0 })
}

async function saveDiscounts() {
  if (!selectedId.value) return
  savingDiscounts.value = true
  try {
    const valid = discountRows.value.filter((r) => r.discount_type_id && r.amount > 0)
    sheet.value = await feesV2Service.setChargeSheetDiscounts(selectedId.value, valid)
    syncDiscountRows()
  } finally {
    savingDiscounts.value = false
  }
}

function openPay(target: 'upfront' | 'installment', inst?: { id: string; amount_due: string; amount_paid: string }) {
  if (!sheet.value) return
  payError.value = ''
  payRemarks.value = ''
  proofFile.value = null
  payTarget.value = target
  if (target === 'installment' && inst) {
    payInstallmentId.value = inst.id
    payAmount.value = Math.max(0, Number(inst.amount_due) - Number(inst.amount_paid))
  } else {
    payInstallmentId.value = null
    payAmount.value = Number(sheet.value.upfront_due)
  }
}

function closePay() {
  payTarget.value = null
  proofFile.value = null
}

function onProofPicked(e: Event) {
  const input = e.target as HTMLInputElement
  proofFile.value = input.files?.[0] ?? null
}

async function submitPay() {
  if (!selectedId.value || !payTarget.value || !proofFile.value || payAmount.value <= 0) return
  paying.value = true
  payError.value = ''
  try {
    await feesV2Service.submitOfflinePayment(selectedId.value, {
      target_type: payTarget.value,
      installment_id: payInstallmentId.value ?? undefined,
      remarks: payRemarks.value,
      locale: locale.value === 'en' ? 'en' : 'ar',
      file: proofFile.value,
    })
    closePay()
    studentPayments.value = await feesV2Service.listStudentPayments(selectedId.value).catch(() => [])
  } catch (e: unknown) {
    const err = e as { message?: string }
    payError.value = err?.message || t('parentFees.payFailed')
  } finally {
    paying.value = false
  }
}

onMounted(async () => {
  await loadStudents()
  try {
    plans.value = await feesV2Service.listInstallmentPlans(schoolId.value)
    discountTypes.value = await paymentConfigService.listDiscountTypes(schoolId.value)
  } catch {
    plans.value = []
    discountTypes.value = []
  }
})
</script>
