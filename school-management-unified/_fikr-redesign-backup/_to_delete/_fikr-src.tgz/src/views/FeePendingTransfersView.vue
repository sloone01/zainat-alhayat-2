<template>
  <DashboardLayout>
    <div class="space-y-6 pb-10" :dir="isRTL ? 'rtl' : 'ltr'">
      <section class="relative overflow-hidden rounded-2xl bg-gradient-to-br from-sky-800 via-sky-700 to-teal-600 p-6 text-white shadow-xl sm:p-8">
        <div class="relative flex items-start gap-3">
          <router-link
            to="/students/payments"
            class="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-md border border-white/30 bg-white/10 text-white hover:bg-white/20 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/50"
            :aria-label="$t('feesV2.backToStudentCharges')"
          >
            <svg class="h-4 w-4 rtl:rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
          </router-link>
          <div>
            <h1 class="text-2xl font-bold tracking-tight sm:text-3xl">{{ $t('feesV2.pendingTransfers') }}</h1>
            <p class="mt-2 max-w-2xl text-sm text-sky-50/95">{{ $t('feesV2.pendingTransfersHint') }}</p>
          </div>
        </div>
      </section>

      <div v-if="actionError" class="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
        {{ actionError }}
      </div>

      <div v-if="loading" class="flex flex-col items-center justify-center gap-3 py-20 text-gray-500">
        <span class="h-10 w-10 animate-spin rounded-full border-2 border-sky-500 border-t-transparent" />
        <span class="text-sm">{{ $t('common.loading') }}</span>
      </div>

      <div
        v-else-if="!transfers.length"
        class="rounded-2xl border border-dashed border-gray-200 bg-white py-16 text-center text-sm text-gray-500 shadow-sm"
      >
        {{ $t('feesV2.pendingTransfersEmpty') }}
      </div>

      <ul v-else class="space-y-4">
        <li
          v-for="tr in transfers"
          :key="tr.id"
          class="overflow-hidden rounded-2xl border border-sky-200/80 bg-white shadow-sm"
        >
          <div class="flex flex-wrap items-center justify-between gap-3 border-b border-sky-100 bg-sky-50/70 px-6 py-4">
            <div>
              <p class="font-semibold text-gray-900">
                {{ fmt(tr.total_amount) }} OMR
                <span v-if="tr.reference" class="text-sm font-normal text-gray-500"> · {{ tr.reference }}</span>
              </p>
              <p class="mt-0.5 text-xs text-sky-800">{{ $t('parentFees.status_pending_reconcile') }}</p>
            </div>
            <div class="flex flex-wrap gap-2">
              <button
                type="button"
                class="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
                :disabled="busyId === tr.id"
                @click="approve(tr.id)"
              >
                {{ $t('feesV2.approveTransfer') }}
              </button>
              <button
                type="button"
                class="rounded-lg border border-red-200 px-4 py-2 text-sm font-semibold text-red-700 hover:bg-red-50 disabled:opacity-50"
                :disabled="busyId === tr.id"
                @click="reject(tr.id)"
              >
                {{ $t('feesV2.rejectTransfer') }}
              </button>
            </div>
          </div>
          <ul class="divide-y divide-gray-100">
            <li
              v-for="line in tr.lines || []"
              :key="line.id"
              class="flex flex-wrap items-center justify-between gap-2 px-6 py-3 text-sm"
            >
              <span>
                {{
                  line.payment?.student
                    ? `${line.payment.student.firstName} ${line.payment.student.lastName}`
                    : line.payment_id
                }}
                · {{ fmt(line.payment?.amount || 0) }} OMR
              </span>
              <a
                v-if="line.payment?.proof_url"
                :href="proofHref(line.payment.proof_url)"
                target="_blank"
                rel="noopener"
                class="text-xs font-medium text-teal-700 hover:underline"
              >
                {{ $t('feesV2.viewReceipt') }}
              </a>
            </li>
          </ul>
        </li>
      </ul>
    </div>
  </DashboardLayout>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import DashboardLayout from '@/layouts/DashboardLayout.vue'
import { feesV2Service, type FeeTransfer } from '@/services/fees-v2.service'
import { mediaUrl } from '@/utils/thawaniCheckout'

const { locale, t } = useI18n()
const isRTL = computed(() => locale.value === 'ar')

const allTransfers = ref<FeeTransfer[]>([])
const loading = ref(true)
const busyId = ref<string | null>(null)
const actionError = ref('')

const transfers = computed(() =>
  allTransfers.value.filter((tr) => tr.status === 'pending_school'),
)

function fmt(v: string | number) {
  return Number(v || 0).toFixed(3)
}

function proofHref(url: string) {
  return mediaUrl(url)
}

async function load() {
  loading.value = true
  try {
    allTransfers.value = await feesV2Service.listFeeTransfers()
  } catch {
    allTransfers.value = []
  } finally {
    loading.value = false
  }
}

async function approve(id: string) {
  busyId.value = id
  actionError.value = ''
  try {
    await feesV2Service.approveFeeTransfer(id)
    await load()
  } catch (e: unknown) {
    actionError.value = (e as { message?: string })?.message || t('feesV2.transferActionError')
  } finally {
    busyId.value = null
  }
}

async function reject(id: string) {
  busyId.value = id
  actionError.value = ''
  try {
    await feesV2Service.rejectFeeTransfer(id)
    await load()
  } catch (e: unknown) {
    actionError.value = (e as { message?: string })?.message || t('feesV2.transferActionError')
  } finally {
    busyId.value = null
  }
}

onMounted(() => {
  void load()
})
</script>
