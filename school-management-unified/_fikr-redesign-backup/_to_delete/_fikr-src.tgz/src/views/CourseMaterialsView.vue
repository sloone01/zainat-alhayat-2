<template>
  <DashboardLayout>
    <div class="space-y-6 pb-10" :dir="isRTL ? 'rtl' : 'ltr'">
      <section class="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-800 via-primary-800 to-teal-800 p-6 text-white shadow-xl sm:p-8">
        <div class="pointer-events-none absolute -end-10 -top-10 h-40 w-40 rounded-full bg-white/10 blur-2xl" aria-hidden="true" />
        <div class="relative flex items-start gap-3">
          <button
            v-if="selectedCourse"
            type="button"
            class="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-md border border-white/30 bg-white/10 text-white hover:bg-white/20 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/50"
            :aria-label="$t('common.back')"
            @click="selectedCourse = null; materials = []"
          >
            <svg class="h-4 w-4 rtl:rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <div>
            <h1 class="text-2xl font-bold tracking-tight sm:text-3xl">{{ $t('courseMaterials.title') }}</h1>
            <p class="mt-2 max-w-2xl text-sm text-slate-200/95">
              <span v-if="!selectedCourse">{{ $t('courseMaterials.selectCourseHint') }}</span>
              <span v-else>{{ selectedCourse.name }}</span>
            </p>
          </div>
        </div>
      </section>

      <!-- Course list -->
      <div v-if="!selectedCourse" class="overflow-hidden rounded-2xl border border-gray-200/80 bg-white shadow-sm">
        <div class="border-b border-gray-100 bg-gradient-to-r from-primary-50/80 to-white px-6 py-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 class="text-lg font-semibold text-gray-900">{{ $t('courseMaterials.coursesHeading') }}</h2>
            <p class="text-xs text-gray-500">{{ $t('courseMaterials.allKindsHint') }}</p>
          </div>
          <select v-model="kindFilter" class="rounded-lg border border-gray-300 px-3 py-2 text-sm">
            <option value="">{{ $t('courseMaterials.allKinds') }}</option>
            <option value="milestone">{{ $t('courseMaterials.kindMilestone') }}</option>
            <option value="graded">{{ $t('courseMaterials.kindGraded') }}</option>
            <option value="standalone">{{ $t('courseMaterials.kindStandalone') }}</option>
          </select>
        </div>
        <div class="p-6">
          <div v-if="loadingCourses" class="flex justify-center py-16">
            <span class="h-10 w-10 animate-spin rounded-full border-2 border-primary-500 border-t-transparent" />
          </div>
          <div v-else-if="!filteredCourses.length" class="py-16 text-center text-sm text-gray-500">
            {{ $t('courseMaterials.noCourses') }}
          </div>
          <div v-else class="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <button
              v-for="c in filteredCourses"
              :key="c.id"
              type="button"
              class="rounded-2xl border border-gray-200/80 bg-white p-5 text-start shadow-sm transition hover:border-primary-200 hover:shadow-md"
              @click="openCourse(c)"
            >
              <div class="flex items-start justify-between gap-2">
                <h3 class="font-semibold text-gray-900">{{ c.name }}</h3>
                <span class="shrink-0 rounded-lg bg-primary-50 px-2 py-0.5 text-[11px] font-semibold text-primary-800 ring-1 ring-primary-100">
                  {{ kindLabel(c.course_kind) }}
                </span>
              </div>
              <p class="mt-3 text-xs text-gray-500">
                {{ $t('courseMaterials.filesCount', { count: c.materials_count }) }}
              </p>
            </button>
          </div>
        </div>
      </div>

      <!-- Materials for course -->
      <div v-else class="space-y-4">
        <div v-if="canManage" class="rounded-2xl border border-gray-200/80 bg-white p-4 shadow-sm sm:p-6">
          <h2 class="text-sm font-semibold text-gray-900">{{ $t('courseMaterials.uploadHeading') }}</h2>
          <p class="mt-1 text-xs text-gray-500">{{ $t('courseMaterials.allowedTypes') }}</p>
          <form class="mt-4 grid gap-3 sm:grid-cols-2" @submit.prevent="submitUpload">
            <div class="sm:col-span-2">
              <label class="mb-1 block text-xs font-medium text-gray-600">{{ $t('courseMaterials.file') }} *</label>
              <input
                ref="fileInput"
                type="file"
                required
                :accept="accept"
                class="block w-full text-sm text-gray-700 file:me-3 file:rounded-lg file:border-0 file:bg-primary-50 file:px-3 file:py-2 file:text-sm file:font-semibold file:text-primary-800"
                @change="onFileChange"
              />
            </div>
            <div>
              <label class="mb-1 block text-xs font-medium text-gray-600">{{ $t('courseMaterials.materialTitle') }} *</label>
              <input v-model="uploadTitle" required class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" />
            </div>
            <div>
              <label class="mb-1 block text-xs font-medium text-gray-600">{{ $t('courseMaterials.description') }}</label>
              <input v-model="uploadDesc" class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" />
            </div>
            <div class="sm:col-span-2 flex flex-wrap items-center gap-3">
              <button
                type="submit"
                class="inline-flex items-center justify-center rounded-lg bg-primary-600 px-4 py-2 text-sm font-medium text-white hover:bg-primary-700 disabled:opacity-50"
                :disabled="uploading || !uploadFile"
              >
                {{ uploading ? $t('common.saving') : $t('courseMaterials.upload') }}
              </button>
              <p v-if="uploadError" class="text-sm text-red-600">{{ uploadError }}</p>
            </div>
          </form>
        </div>

        <div class="overflow-hidden rounded-2xl border border-gray-200/80 bg-white shadow-sm">
          <div class="border-b border-gray-100 px-6 py-4">
            <h2 class="text-lg font-semibold text-gray-900">{{ $t('courseMaterials.listHeading') }}</h2>
          </div>
          <div v-if="loadingMaterials" class="flex justify-center py-12">
            <span class="h-10 w-10 animate-spin rounded-full border-2 border-primary-500 border-t-transparent" />
          </div>
          <div v-else-if="!materials.length" class="py-12 text-center text-sm text-gray-500">
            {{ $t('courseMaterials.noMaterials') }}
          </div>
          <ul v-else class="divide-y divide-gray-100">
            <li
              v-for="m in materials"
              :key="m.id"
              class="flex flex-col gap-3 px-6 py-4 sm:flex-row sm:items-center sm:justify-between"
            >
              <div class="min-w-0">
                <div class="font-medium text-gray-900">{{ m.title }}</div>
                <div class="mt-0.5 truncate text-xs text-gray-500">
                  {{ m.original_filename }} · {{ formatSize(m.file_size) }}
                  <span v-if="!m.is_visible" class="ms-2 text-amber-700">({{ $t('courseMaterials.hidden') }})</span>
                </div>
                <p v-if="m.description" class="mt-1 text-xs text-gray-600">{{ m.description }}</p>
              </div>
              <div class="flex flex-wrap gap-2">
                <button
                  type="button"
                  class="rounded-lg border border-primary-200 bg-primary-50 px-3 py-1.5 text-sm font-medium text-primary-800 hover:bg-primary-100"
                  @click="download(m)"
                >
                  {{ $t('courseMaterials.download') }}
                </button>
                <button
                  v-if="canManage"
                  type="button"
                  class="rounded-lg border border-gray-200 px-3 py-1.5 text-sm text-gray-700 hover:bg-gray-50"
                  @click="toggleVisible(m)"
                >
                  {{ m.is_visible ? $t('courseMaterials.hide') : $t('courseMaterials.show') }}
                </button>
                <button
                  v-if="canManage"
                  type="button"
                  class="rounded-lg border border-red-200 px-3 py-1.5 text-sm text-red-700 hover:bg-red-50"
                  @click="remove(m)"
                >
                  {{ $t('common.delete') }}
                </button>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </DashboardLayout>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import { useRoute } from 'vue-router'
import DashboardLayout from '@/layouts/DashboardLayout.vue'
import authService from '@/services/auth.service'
import courseMaterialService, {
  COURSE_MATERIAL_ACCEPT,
  type CourseMaterialCourseRow,
  type CourseMaterialRow,
} from '@/services/course-material.service'

const { t, locale } = useI18n()
const route = useRoute()
const isRTL = computed(() => locale.value === 'ar')
const user = computed(() => authService.getStoredUser())
const schoolId = computed(() => user.value?.school_id ?? 1)
const canManage = computed(
  () => user.value?.role === 'admin' || user.value?.role === 'teacher',
)
const accept = COURSE_MATERIAL_ACCEPT

const courses = ref<CourseMaterialCourseRow[]>([])
const kindFilter = ref('')
const loadingCourses = ref(false)
const selectedCourse = ref<CourseMaterialCourseRow | null>(null)
const materials = ref<CourseMaterialRow[]>([])
const loadingMaterials = ref(false)

const uploadFile = ref<File | null>(null)
const uploadTitle = ref('')
const uploadDesc = ref('')
const uploading = ref(false)
const uploadError = ref('')
const fileInput = ref<HTMLInputElement | null>(null)

const filteredCourses = computed(() => {
  if (!kindFilter.value) return courses.value
  return courses.value.filter((c) => c.course_kind === kindFilter.value)
})

function kindLabel(kind: string) {
  if (kind === 'graded') return t('courseMaterials.kindGraded')
  if (kind === 'standalone') return t('courseMaterials.kindStandalone')
  return t('courseMaterials.kindMilestone')
}

function formatSize(n: number) {
  if (n < 1024) return `${n} B`
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`
  return `${(n / (1024 * 1024)).toFixed(1)} MB`
}

async function loadCourses() {
  loadingCourses.value = true
  try {
    courses.value = await courseMaterialService.listCourses(schoolId.value)
    const q = String(route.query.course || '')
    if (q) {
      const match = courses.value.find((c) => c.id === q)
      if (match) await openCourse(match)
    }
  } catch {
    courses.value = []
  } finally {
    loadingCourses.value = false
  }
}

async function openCourse(c: CourseMaterialCourseRow) {
  selectedCourse.value = c
  await loadMaterials()
}

async function loadMaterials() {
  if (!selectedCourse.value) return
  loadingMaterials.value = true
  try {
    materials.value = await courseMaterialService.list(
      schoolId.value,
      selectedCourse.value.id,
    )
  } catch {
    materials.value = []
  } finally {
    loadingMaterials.value = false
  }
}

function onFileChange(e: Event) {
  const input = e.target as HTMLInputElement
  const f = input.files?.[0] || null
  uploadFile.value = f
  if (f && !uploadTitle.value) {
    uploadTitle.value = f.name.replace(/\.[^.]+$/, '')
  }
}

async function submitUpload() {
  if (!selectedCourse.value || !uploadFile.value) return
  uploading.value = true
  uploadError.value = ''
  try {
    await courseMaterialService.upload({
      schoolId: schoolId.value,
      courseId: selectedCourse.value.id,
      title: uploadTitle.value,
      description: uploadDesc.value || undefined,
      file: uploadFile.value,
    })
    uploadFile.value = null
    uploadTitle.value = ''
    uploadDesc.value = ''
    if (fileInput.value) fileInput.value.value = ''
    await loadMaterials()
    const refreshed = await courseMaterialService.listCourses(schoolId.value)
    courses.value = refreshed
    if (selectedCourse.value) {
      selectedCourse.value =
        refreshed.find((c) => c.id === selectedCourse.value!.id) ||
        selectedCourse.value
    }
  } catch (e: unknown) {
    uploadError.value =
      (e as { message?: string })?.message || t('courseMaterials.uploadFailed')
  } finally {
    uploading.value = false
  }
}

async function download(m: CourseMaterialRow) {
  try {
    const { blob, filename } = await courseMaterialService.downloadBlob(
      schoolId.value,
      m.id,
    )
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = filename || m.original_filename
    a.click()
    URL.revokeObjectURL(url)
  } catch {
    /* ignore */
  }
}

async function toggleVisible(m: CourseMaterialRow) {
  await courseMaterialService.update(schoolId.value, m.id, {
    is_visible: !m.is_visible,
  })
  await loadMaterials()
}

async function remove(m: CourseMaterialRow) {
  if (!confirm(t('courseMaterials.confirmDelete'))) return
  await courseMaterialService.remove(schoolId.value, m.id)
  await loadMaterials()
  await loadCourses()
}

onMounted(() => {
  void loadCourses()
})
</script>
