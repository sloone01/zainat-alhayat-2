<template>
  <DashboardLayout>
    <div class="space-y-6 pb-10" :dir="isRTL ? 'rtl' : 'ltr'">
      <section class="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-800 via-primary-800 to-teal-800 p-6 text-white shadow-xl sm:p-8">
        <div class="relative flex items-start gap-3">
          <router-link
            to="/reports"
            class="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-md border border-white/30 bg-white/10 text-white hover:bg-white/20 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/50"
            :aria-label="$t('reports.backToReports')"
          >
            <svg class="h-4 w-4 rtl:rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
          </router-link>
          <div>
            <h1 class="text-2xl font-bold tracking-tight sm:text-3xl">{{ $t('reports.gradedClassTitle') }}</h1>
            <p class="mt-2 max-w-2xl text-sm text-slate-200/95">{{ $t('reports.gradedClassDesc') }}</p>
          </div>
        </div>
      </section>

      <div class="rounded-2xl border border-gray-200/80 bg-white p-4 shadow-sm sm:p-6">
        <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <div>
            <label class="mb-1 block text-xs font-semibold text-gray-600">{{ $t('progressTracking.selectGroup') }}</label>
            <select v-model="groupId" class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" @change="onGroupChange">
              <option value="">{{ $t('common.select') }}</option>
              <option v-for="g in groups" :key="g.id" :value="g.id">{{ g.name }}</option>
            </select>
          </div>
          <div>
            <label class="mb-1 block text-xs font-semibold text-gray-600">{{ $t('gradedMarksGrid.selectCourse') }}</label>
            <select v-model="courseId" class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" :disabled="!groupId">
              <option value="">{{ $t('common.select') }}</option>
              <option v-for="c in courses" :key="c.id" :value="c.id">{{ c.title }}</option>
            </select>
          </div>
          <div class="flex items-end">
            <button
              type="button"
              class="inline-flex w-full items-center justify-center rounded-lg bg-primary-600 px-4 py-2 text-sm font-medium text-white hover:bg-primary-700 disabled:opacity-50"
              :disabled="!groupId || !courseId || loading"
              @click="loadReport"
            >
              {{ loading ? $t('common.loading') : $t('reports.runReport') }}
            </button>
          </div>
        </div>
        <p v-if="error" class="mt-3 text-sm text-red-600">{{ error }}</p>
      </div>

      <div v-if="report" class="overflow-hidden rounded-2xl border border-gray-200/80 bg-white shadow-sm">
        <div class="border-b border-gray-100 px-6 py-4">
          <h2 class="text-lg font-semibold text-gray-900">{{ report.course_name }}</h2>
          <p class="text-sm text-gray-600">{{ report.group_name }} · {{ $t('gradedMarksGrid.courseTotalMarks') }}: {{ report.total_marks }}</p>
        </div>
        <div class="overflow-x-auto">
          <table class="min-w-full text-sm">
            <thead class="bg-gray-50 text-xs uppercase tracking-wide text-gray-500">
              <tr>
                <th class="px-4 py-3 text-start font-semibold">{{ $t('progressTracking.studentName') }}</th>
                <th
                  v-for="c in report.criteria"
                  :key="c.id"
                  class="px-2 py-3 text-center font-semibold"
                  :title="c.label"
                >
                  <div class="mx-auto max-w-[100px] truncate normal-case">{{ c.label }}</div>
                  <div class="font-normal text-gray-400">/{{ c.max_marks }}</div>
                </th>
                <th class="px-4 py-3 text-center font-semibold text-emerald-800">{{ $t('reports.calculatedScore') }}</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
              <tr v-for="s in report.students" :key="s.id" class="hover:bg-gray-50">
                <td class="px-4 py-3 font-medium text-gray-900">{{ s.name }}</td>
                <td
                  v-for="c in report.criteria"
                  :key="`${s.id}-${c.id}`"
                  class="px-2 py-3 text-center tabular-nums text-gray-700"
                >
                  {{ s.marks[c.id] == null ? '—' : s.marks[c.id] }}
                </td>
                <td class="px-4 py-3 text-center font-semibold tabular-nums text-emerald-800">
                  {{ s.course_score }} / {{ s.course_max }}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div v-if="!report.students.length" class="py-12 text-center text-sm text-gray-500">
          {{ $t('gradedMarksGrid.noStudents') }}
        </div>
      </div>
    </div>
  </DashboardLayout>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import DashboardLayout from '@/layouts/DashboardLayout.vue'
import { groupService } from '@/services/group.service'
import { scheduleService } from '@/services/schedule.service'
import authService from '@/services/auth.service'
import gradedCriterionMarksService, {
  type ClassMarksReport,
} from '@/services/graded-criterion-marks.service'

const { locale } = useI18n()
const isRTL = computed(() => locale.value === 'ar')
const schoolId = computed(() => authService.getStoredUser()?.school_id ?? 1)

const groups = ref<{ id: string; name: string }[]>([])
const courses = ref<{ id: string; title: string }[]>([])
const groupId = ref('')
const courseId = ref('')
const loading = ref(false)
const error = ref('')
const report = ref<ClassMarksReport | null>(null)

async function loadGroups() {
  const all = await groupService.getAll()
  groups.value = all.map((g) => ({ id: g.id, name: g.name }))
}

async function onGroupChange() {
  courseId.value = ''
  courses.value = []
  report.value = null
  if (!groupId.value) return
  const schedules = await scheduleService.getSchedulesByGroup(groupId.value)
  const map = new Map<string, { id: string; title: string }>()
  for (const s of schedules) {
    if (!s.course_id || s.course?.course_kind !== 'graded') continue
    if (map.has(s.course_id)) continue
    map.set(s.course_id, {
      id: s.course_id,
      title: s.course?.name || s.course?.title || s.course_id,
    })
  }
  courses.value = [...map.values()]
}

async function loadReport() {
  if (!groupId.value || !courseId.value) return
  loading.value = true
  error.value = ''
  try {
    report.value = await gradedCriterionMarksService.classReport({
      schoolId: schoolId.value,
      groupId: groupId.value,
      courseId: courseId.value,
    })
  } catch (e: unknown) {
    report.value = null
    error.value = (e as { message?: string })?.message || 'Failed to load report'
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  void loadGroups()
})
</script>
