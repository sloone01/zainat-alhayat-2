<template>
  <DashboardLayout>
    <div class="space-y-6 pb-10" :dir="isRTL ? 'rtl' : 'ltr'">
      <section class="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-800 via-primary-800 to-teal-800 p-6 text-white shadow-xl sm:p-8">
        <div class="pointer-events-none absolute -end-10 -top-10 h-40 w-40 rounded-full bg-white/10 blur-2xl" aria-hidden="true" />
        <div class="pointer-events-none absolute -bottom-8 start-8 h-32 w-32 rounded-full bg-teal-400/20 blur-2xl" aria-hidden="true" />
        <div class="relative">
          <h1 class="text-2xl font-bold tracking-tight sm:text-3xl">{{ $t('systemSettings.feeItemsLines') }}</h1>
        </div>
      </section>

      <div v-if="flashError" class="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800 shadow-sm">
        <div class="flex items-start gap-3">
          <svg class="mt-0.5 h-5 w-5 shrink-0 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <span>{{ flashError }}</span>
        </div>
      </div>

      <div class="rounded-2xl border border-gray-200/80 bg-white shadow-sm ring-1 ring-black/[0.02]">
        <div class="border-b border-gray-100 px-6 py-5">
          <div class="flex flex-wrap items-center justify-between gap-3">
            <h2 class="text-lg font-semibold text-gray-900">{{ $t('paymentSettings.chargeItemsListHeading') }}</h2>
            <div class="flex flex-wrap items-center gap-2">
              <button
                type="button"
                class="relative inline-flex h-9 w-9 items-center justify-center rounded-lg border border-gray-200 bg-white text-gray-600 hover:bg-gray-50 hover:text-gray-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-500/40"
                :aria-label="$t('common.filter')"
                :aria-expanded="showFilters"
                @click="showFilters = true"
              >
                <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4h18l-7 8v6l-4 2v-8L3 4z" />
                </svg>
                <span
                  v-if="hasActiveFilters"
                  class="absolute end-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-primary-600"
                  aria-hidden="true"
                />
              </button>
              <ListViewModeToggle v-model="viewMode" />
              <button
                type="button"
                class="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-primary-600 text-white hover:bg-primary-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-500/40"
                :aria-label="$t('paymentSettings.addChargeItem')"
                @click="openCreate"
              >
                <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                </svg>
              </button>
            </div>
          </div>
        </div>

        <div class="p-6">
          <div v-if="loading" class="flex flex-col items-center justify-center gap-3 py-16 text-gray-500">
            <span class="h-10 w-10 animate-spin rounded-full border-2 border-primary-500 border-t-transparent" aria-hidden="true" />
            <span class="text-sm">{{ $t('common.loading') }}</span>
          </div>

          <template v-else-if="rows.length">
            <p
              v-if="filteredRows.length === 0"
              class="rounded-md border border-gray-200 bg-gray-50 px-4 py-8 text-center text-sm text-gray-500"
            >
              {{ $t('paymentSettings.noChargeFilterResults') }}
            </p>
            <div v-else-if="isCards" class="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <article
                v-for="row in filteredRows"
                :key="row.id"
                class="relative rounded-2xl border border-gray-200/80 bg-white shadow-sm transition-all hover:border-primary-200 hover:shadow-md"
                :class="!row.is_active ? 'opacity-75' : ''"
              >
                <div
                  class="absolute inset-x-0 top-0 h-1 rounded-t-2xl bg-gradient-to-r from-primary-500 to-teal-500 opacity-80"
                  aria-hidden="true"
                />
                <div class="flex items-center gap-3 p-5">
                  <div class="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary-100 text-primary-800">
                    <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 14l6-6m-5.5.5h.01m4.99 5h.01M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16l3.5-2 3.5 2 3.5-2 3.5 2z" />
                    </svg>
                  </div>
                  <div class="min-w-0 flex-1">
                    <h3 class="truncate font-semibold text-gray-900">{{ row.label }}</h3>
                    <p class="mt-0.5 font-mono text-xs text-gray-500">{{ row.code }}</p>
                  </div>
                  <span
                    class="inline-flex shrink-0 items-center rounded-full px-2.5 py-0.5 text-[11px] font-semibold"
                    :class="row.is_active ? 'bg-emerald-50 text-emerald-800 ring-1 ring-emerald-100' : 'bg-gray-100 text-gray-500'"
                  >
                    {{ row.is_active ? $t('paymentSettings.active') : $t('paymentSettings.inactive') }}
                  </span>
                  <RowActionsMenu
                    :open="activeMenuId === row.id"
                    placement="up"
                    @toggle="toggleMenu(row.id)"
                  >
                    <RowActionsItem icon="edit" @click="openEdit(row)">
                      {{ $t('common.edit') }}
                    </RowActionsItem>
                    <RowActionsItem
                      :icon="row.is_active ? 'archive' : 'activate'"
                      @click="onSetActive(row, !row.is_active)"
                    >
                      {{ row.is_active ? $t('paymentSettings.markInactive') : $t('paymentSettings.markActive') }}
                    </RowActionsItem>
                    <RowActionsItem icon="delete" danger @click="onDelete(row)">
                      {{ $t('common.delete') }}
                    </RowActionsItem>
                  </RowActionsMenu>
                </div>
              </article>
            </div>

            <div v-else class="overflow-x-auto rounded-xl border border-gray-200/80">
              <table class="min-w-full text-sm">
                <thead class="bg-gray-50 text-xs uppercase tracking-wide text-gray-500">
                  <tr>
                    <th class="px-4 py-3 text-start">{{ $t('paymentSettings.label') }}</th>
                    <th class="px-4 py-3 text-start">{{ $t('paymentSettings.code') }}</th>
                    <th class="px-4 py-3 text-start">{{ $t('common.status') }}</th>
                    <th class="px-4 py-3 text-end">{{ $t('common.actions') }}</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                  <tr v-for="row in filteredRows" :key="'list-' + row.id" class="hover:bg-primary-50/20">
                    <td class="px-4 py-3 font-medium text-gray-900">{{ row.label }}</td>
                    <td class="px-4 py-3 font-mono text-xs text-gray-600">{{ row.code }}</td>
                    <td class="px-4 py-3">
                      <span
                        class="inline-flex rounded-full px-2 py-0.5 text-[11px] font-semibold"
                        :class="row.is_active ? 'bg-emerald-50 text-emerald-800' : 'bg-gray-100 text-gray-500'"
                      >
                        {{ row.is_active ? $t('paymentSettings.active') : $t('paymentSettings.inactive') }}
                      </span>
                    </td>
                    <td class="px-4 py-3">
                      <div class="flex justify-end">
                        <RowActionsMenu
                          :open="activeMenuId === row.id"
                          placement="up"
                          @toggle="toggleMenu(row.id)"
                        >
                          <RowActionsItem icon="edit" @click="openEdit(row)">
                            {{ $t('common.edit') }}
                          </RowActionsItem>
                          <RowActionsItem
                            :icon="row.is_active ? 'archive' : 'activate'"
                            @click="onSetActive(row, !row.is_active)"
                          >
                            {{ row.is_active ? $t('paymentSettings.markInactive') : $t('paymentSettings.markActive') }}
                          </RowActionsItem>
                          <RowActionsItem icon="delete" danger @click="onDelete(row)">
                            {{ $t('common.delete') }}
                          </RowActionsItem>
                        </RowActionsMenu>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </template>

          <div v-else class="flex min-h-[16rem] flex-col items-center justify-center text-center">
            <div class="mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-gray-100 text-gray-400">
              <svg class="h-7 w-7" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 14l6-6m-5.5.5h.01m4.99 5h.01M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16l3.5-2 3.5 2 3.5-2 3.5 2z" />
              </svg>
            </div>
            <p class="text-sm font-medium text-gray-600">{{ $t('paymentSettings.emptyCharges') }}</p>
          </div>
        </div>
      </div>
    </div>

    <div
      v-if="showFilters"
      class="fixed inset-0 z-50"
      role="dialog"
      aria-modal="true"
      :aria-label="$t('paymentSettings.filtersTitle')"
    >
      <div class="absolute inset-0 bg-gray-900/40" @click="showFilters = false" />
      <aside
        class="absolute inset-y-0 end-0 flex w-full max-w-sm flex-col bg-white shadow-xl"
        :dir="isRTL ? 'rtl' : 'ltr'"
      >
        <div class="flex items-center justify-between border-b border-gray-200 px-4 py-3">
          <h3 class="text-base font-semibold text-gray-900">{{ $t('paymentSettings.filtersTitle') }}</h3>
          <button
            type="button"
            class="text-gray-400 hover:text-gray-600"
            :aria-label="$t('common.close')"
            @click="showFilters = false"
          >
            <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div class="flex-1 space-y-5 overflow-y-auto px-4 py-5">
          <div>
            <label class="mb-1.5 block text-sm font-medium text-gray-900" for="charges-search">
              {{ $t('common.search') }}
            </label>
            <input
              id="charges-search"
              v-model="searchQuery"
              type="search"
              class="w-full rounded-lg border border-gray-200 bg-white px-3 py-2.5 text-sm text-gray-900 placeholder:text-gray-400 focus:border-primary-400 focus:outline-none focus:ring-2 focus:ring-primary-500/20"
              :placeholder="$t('paymentSettings.searchChargesPlaceholder')"
            >
          </div>
          <div>
            <label class="mb-1.5 block text-sm font-medium text-gray-900" for="charges-status">
              {{ $t('common.status') }}
            </label>
            <select
              id="charges-status"
              v-model="statusFilter"
              class="w-full rounded-lg border border-gray-200 px-3 py-2.5 text-sm text-gray-900 focus:border-primary-400 focus:outline-none focus:ring-2 focus:ring-primary-500/20"
            >
              <option value="all">{{ $t('paymentSettings.allStatuses') }}</option>
              <option value="active">{{ $t('paymentSettings.active') }}</option>
              <option value="inactive">{{ $t('paymentSettings.inactive') }}</option>
            </select>
          </div>
        </div>
        <div class="flex justify-end gap-2 border-t border-gray-200 px-4 py-3">
          <button
            type="button"
            class="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
            @click="clearFilters"
          >
            {{ $t('common.clear') }}
          </button>
          <button
            type="button"
            class="rounded-md bg-primary-600 px-4 py-2 text-sm font-semibold text-white hover:bg-primary-700"
            @click="showFilters = false"
          >
            {{ $t('common.close') }}
          </button>
        </div>
      </aside>
    </div>

    <div
      v-if="showForm"
      class="fixed inset-0 z-50 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      :aria-labelledby="formTitleId"
    >
      <div class="flex min-h-full items-center justify-center p-4">
        <div class="fixed inset-0 bg-gray-900/45 backdrop-blur-[1px]" @click="closeForm" />
        <div class="relative w-full max-w-lg overflow-hidden rounded-2xl bg-white shadow-xl ring-1 ring-black/5" :dir="isRTL ? 'rtl' : 'ltr'">
          <div class="flex items-center justify-between border-b border-gray-100 px-5 py-4">
            <h3 :id="formTitleId" class="text-lg font-semibold text-gray-900">
              {{ editingRow ? $t('paymentSettings.editChargeItem') : $t('paymentSettings.addChargeItem') }}
            </h3>
            <button
              type="button"
              class="text-gray-400 hover:text-gray-600"
              :aria-label="$t('common.close')"
              @click="closeForm"
            >
              <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          <form class="space-y-4 px-5 py-5" @submit.prevent="saveForm">
            <div>
              <label class="mb-1.5 block text-sm font-medium text-gray-900" for="charge-code">
                {{ $t('paymentSettings.code') }}
              </label>
              <input
                id="charge-code"
                v-model="form.code"
                required
                class="w-full rounded-lg border border-gray-200 px-3 py-2.5 text-sm text-gray-900 focus:border-primary-400 focus:outline-none focus:ring-2 focus:ring-primary-500/20"
              >
            </div>
            <div>
              <label class="mb-1.5 block text-sm font-medium text-gray-900" for="charge-label">
                {{ $t('paymentSettings.label') }}
              </label>
              <input
                id="charge-label"
                v-model="form.label"
                required
                class="w-full rounded-lg border border-gray-200 px-3 py-2.5 text-sm text-gray-900 focus:border-primary-400 focus:outline-none focus:ring-2 focus:ring-primary-500/20"
              >
            </div>
            <p v-if="formError" class="text-sm text-red-700">{{ formError }}</p>
            <div class="flex justify-end gap-2 border-t border-gray-100 pt-4">
              <button
                type="button"
                class="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
                @click="closeForm"
              >
                {{ $t('common.cancel') }}
              </button>
              <button
                type="submit"
                class="rounded-md bg-primary-600 px-4 py-2 text-sm font-semibold text-white hover:bg-primary-700 disabled:opacity-50"
                :disabled="saving"
              >
                {{ saving ? $t('common.saving') : $t('common.save') }}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </DashboardLayout>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useI18n } from 'vue-i18n'
import DashboardLayout from '@/layouts/DashboardLayout.vue'
import ListViewModeToggle from '@/components/ListViewModeToggle.vue'
import RowActionsMenu from '@/components/RowActionsMenu.vue'
import RowActionsItem from '@/components/RowActionsItem.vue'
import { useListViewMode } from '@/composables/useListViewMode'
import { authService } from '@/services'
import paymentConfigService, { type PaymentCatalogRow } from '@/services/payment-config.service'

const { locale, t } = useI18n()
const isRTL = computed(() => locale.value === 'ar')
const { viewMode, isCards } = useListViewMode()
const schoolId = computed(() => {
  const u = authService.getStoredUser()
  return u?.school_id != null ? Number(u.school_id) : 1
})

const formTitleId = 'charge-item-form-title'

const rows = ref<PaymentCatalogRow[]>([])
const loading = ref(true)
const flashError = ref('')
const showFilters = ref(false)
const searchQuery = ref('')
const statusFilter = ref<'all' | 'active' | 'inactive'>('all')
const activeMenuId = ref<string | null>(null)

const showForm = ref(false)
const editingRow = ref<PaymentCatalogRow | null>(null)
const saving = ref(false)
const formError = ref('')
const form = ref({
  code: '',
  label: '',
})

const hasActiveFilters = computed(() =>
  Boolean(searchQuery.value.trim()) || statusFilter.value !== 'all',
)

const filteredRows = computed(() => {
  const q = searchQuery.value.trim().toLowerCase()
  return rows.value.filter((row) => {
    if (statusFilter.value === 'active' && !row.is_active) return false
    if (statusFilter.value === 'inactive' && row.is_active) return false
    if (q && !`${row.label} ${row.code}`.toLowerCase().includes(q)) return false
    return true
  })
})

function clearFilters() {
  searchQuery.value = ''
  statusFilter.value = 'all'
}

function toggleMenu(id: string) {
  activeMenuId.value = activeMenuId.value === id ? null : id
}

function closeMenu() {
  activeMenuId.value = null
}

function handleClickOutside(event: Event) {
  if (activeMenuId.value && !(event.target as Element).closest('.relative')) {
    closeMenu()
  }
}

function resetForm() {
  form.value = { code: '', label: '' }
  formError.value = ''
  editingRow.value = null
}

function openCreate() {
  resetForm()
  showForm.value = true
}

function openEdit(row: PaymentCatalogRow) {
  closeMenu()
  editingRow.value = row
  form.value = {
    code: row.code,
    label: row.label,
  }
  formError.value = ''
  showForm.value = true
}

function closeForm() {
  if (saving.value) return
  showForm.value = false
  resetForm()
}

async function load() {
  loading.value = true
  flashError.value = ''
  try {
    rows.value = await paymentConfigService.listChargeTypes(schoolId.value)
  } catch (e: unknown) {
    flashError.value = (e as { message?: string })?.message || t('paymentSettings.loadError')
  } finally {
    loading.value = false
  }
}

async function saveForm() {
  formError.value = ''
  saving.value = true
  try {
    const payload = {
      code: form.value.code.trim(),
      label: form.value.label.trim(),
    }
    if (editingRow.value) {
      const updated = await paymentConfigService.updateChargeType(editingRow.value.id, payload)
      const i = rows.value.findIndex((x) => x.id === editingRow.value?.id)
      if (i !== -1) rows.value[i] = updated
    } else {
      const row = await paymentConfigService.createChargeType(schoolId.value, {
        ...payload,
        value: null,
      })
      rows.value = [...rows.value, row]
    }
    showForm.value = false
    resetForm()
  } catch (e: unknown) {
    formError.value = (e as { message?: string })?.message || t('paymentSettings.saveError')
  } finally {
    saving.value = false
  }
}

async function onSetActive(row: PaymentCatalogRow, is_active: boolean) {
  closeMenu()
  try {
    const updated = await paymentConfigService.updateChargeType(row.id, { is_active })
    const i = rows.value.findIndex((x) => x.id === row.id)
    if (i !== -1) rows.value[i] = updated
  } catch {
    await load()
  }
}

async function onDelete(row: PaymentCatalogRow) {
  closeMenu()
  if (!confirm(t('paymentSettings.confirmDelete'))) return
  try {
    await paymentConfigService.deleteChargeType(row.id)
    rows.value = rows.value.filter((x) => x.id !== row.id)
  } catch (e: unknown) {
    flashError.value = (e as { message?: string })?.message || t('paymentSettings.saveError')
  }
}

onMounted(() => {
  document.addEventListener('click', handleClickOutside)
  void load()
})

onUnmounted(() => {
  document.removeEventListener('click', handleClickOutside)
})
</script>
