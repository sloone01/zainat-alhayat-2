<template>
  <DashboardLayout>
    <div class="space-y-6 pb-10" :dir="isRTL ? 'rtl' : 'ltr'">
      <section class="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-800 via-primary-800 to-teal-800 p-6 text-white shadow-xl sm:p-8">
        <div class="relative">
          <h1 class="text-2xl font-bold tracking-tight sm:text-3xl">{{ $t('platformFeePayments.title') }}</h1>
          <p class="mt-2 max-w-2xl text-sm text-slate-200/95">{{ $t('platformFeePayments.subtitle') }}</p>
        </div>
      </section>

      <div v-if="error" class="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
        <span>{{ error }}</span>
        <button type="button" class="ms-3 font-semibold underline" @click="load">{{ $t('common.retry') }}</button>
      </div>

      <section class="overflow-hidden rounded-2xl border border-gray-200/80 bg-white shadow-sm">
        <div class="border-b border-gray-100 bg-amber-50/60 px-6 py-4">
          <h2 class="text-lg font-semibold text-gray-900">{{ $t('feesV2.pendingApprovals') }}</h2>
          <p class="mt-0.5 text-xs text-gray-600">{{ $t('platformFeePayments.hint') }}</p>
        </div>

        <div v-if="loading" class="flex items-center justify-center py-16 text-gray-500">
          <span class="h-8 w-8 animate-spin rounded-full border-2 border-primary-200 border-t-primary-600" />
        </div>
        <div v-else-if="!pending.length" class="px-6 py-12 text-center text-sm text-gray-500">
          {{ $t('platformFeePayments.empty') }}
        </div>
        <ul v-else class="divide-y divide-gray-100">
          <li v-for="p in pending" :key="p.id" class="flex flex-wrap items-center justify-between gap-4 px-6 py-4">
            <div class="min-w-0">
              <p class="font-semibold text-gray-900">
                {{ p.school?.name || $t('platformFeePayments.schoolFallback') }}
                · {{ studentName(p) }}
              </p>
              <p class="mt-0.5 text-sm tabular-nums text-gray-800">{{ formatMoney(p.amount) }}</p>
              <p class="text-xs text-gray-500">
                {{ $t(`parentFees.method_${p.method}`) }}
                <span v-if="p.remarks"> · {{ p.remarks }}</span>
              </p>
              <a
                v-if="p.proof_url"
                :href="mediaUrl(p.proof_url)"
                target="_blank"
                rel="noopener"
                class="mt-1 inline-block text-xs font-medium text-teal-700 hover:underline"
              >
                {{ $t('feesV2.viewReceipt') }}
              </a>
            </div>
            <div class="flex gap-2">
              <button
                type="button"
                class="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
                :disabled="busyId === p.id"
                @click="approve(p.id)"
              >
                {{ $t('feesV2.approvePayment') }}
              </button>
              <button
                type="button"
                class="rounded-lg border border-red-200 px-3 py-1.5 text-xs font-semibold text-red-700 hover:bg-red-50 disabled:opacity-50"
                :disabled="busyId === p.id"
                @click="reject(p.id)"
              >
                {{ $t('feesV2.rejectPayment') }}
              </button>
            </div>
          </li>
        </ul>
      </section>
    </div>
  </DashboardLayout>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import DashboardLayout from '@/layouts/DashboardLayout.vue'
import { feesV2Service, type FeePayment } from '@/services/fees-v2.service'
import { mediaUrl } from '@/utils/thawaniCheckout'

const { locale, t } = useI18n()
const isRTL = computed(() => locale.value === 'ar')
const pending = ref<FeePayment[]>([])
const loading = ref(true)
const error = ref('')
const busyId = ref<string | null>(null)

function studentName(p?: FeePayment | null) {
  if (!p) return '—'
  return p.student ? `${p.student.firstName} ${p.student.lastName}` : p.student_id
}

function formatMoney(v: string | number) {
  const n = Number(v || 0)
  try {
    return new Intl.NumberFormat(locale.value === 'ar' ? 'ar-OM' : 'en-OM', {
      style: 'currency',
      currency: 'OMR',
      minimumFractionDigits: 3,
      maximumFractionDigits: 3,
    }).format(n)
  } catch {
    return `${n.toFixed(3)} OMR`
  }
}

async function load() {
  loading.value = true
  error.value = ''
  try {
    pending.value = await feesV2Service.listPendingPayments()
  } catch (e: unknown) {
    const err = e as { message?: string }
    error.value = err?.message || t('platformFeePayments.loadError')
    pending.value = []
  } finally {
    loading.value = false
  }
}

async function approve(id: string) {
  busyId.value = id
  try {
    await feesV2Service.approvePayment(id)
    await load()
  } catch (e: unknown) {
    const err = e as { message?: string }
    error.value = err?.message || t('platformFeePayments.actionError')
  } finally {
    busyId.value = null
  }
}

async function reject(id: string) {
  busyId.value = id
  try {
    await feesV2Service.rejectPayment(id)
    await load()
  } catch (e: unknown) {
    const err = e as { message?: string }
    error.value = err?.message || t('platformFeePayments.actionError')
  } finally {
    busyId.value = null
  }
}

onMounted(load)
</script>
