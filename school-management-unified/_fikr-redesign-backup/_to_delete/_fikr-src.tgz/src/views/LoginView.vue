<template>
  <div class="flex min-h-screen bg-white font-sans" :dir="isRTL ? 'rtl' : 'ltr'">
    <!-- ───────── Brand tile (navy) — inline-start side, as in the FIKR mock ───────── -->
    <aside class="relative hidden w-[46%] flex-col justify-between overflow-hidden bg-navy-800 px-10 py-9 text-white lg:flex xl:px-16">
      <!-- wordmark + pixel motif -->
      <div class="flex items-center justify-end gap-3">
        <span class="text-xl font-bold tracking-[0.04em] text-white" dir="ltr">FIKR</span>
        <span class="grid grid-cols-3 gap-1" aria-hidden="true">
          <i class="h-2.5 w-2.5 rounded-[2px] bg-primary-400" />
          <i class="h-2.5 w-2.5 rounded-[2px] bg-transparent" />
          <i class="h-2.5 w-2.5 rounded-[2px] bg-primary-400/50" />
          <i class="h-2.5 w-2.5 rounded-[2px] bg-transparent" />
          <i class="h-2.5 w-2.5 rounded-[2px] bg-primary-400" />
          <i class="h-2.5 w-2.5 rounded-[2px] bg-transparent" />
          <i class="h-2.5 w-2.5 rounded-[2px] bg-primary-400/70" />
          <i class="h-2.5 w-2.5 rounded-[2px] bg-transparent" />
          <i class="h-2.5 w-2.5 rounded-[2px] bg-primary-400" />
        </span>
      </div>

      <!-- headline -->
      <div class="relative max-w-md">
        <h2 class="text-[44px] font-bold leading-[1.15] tracking-[-0.01em] text-white xl:text-[56px] xl:leading-[1.1]">
          {{ $t('login.heroTitle') }}
        </h2>
        <p class="mt-5 text-lg leading-relaxed text-white/80 xl:text-xl">
          {{ heroSubtitle }}
        </p>
      </div>

      <!-- footer line -->
      <p class="text-xs text-white/60">{{ $t('login.footerBrand') }}</p>

      <!-- soft teal glow (flat design — no shadows, just a tonal wash) -->
      <div
        class="pointer-events-none absolute -bottom-32 -start-32 h-96 w-96 rounded-full bg-primary-500/10"
        aria-hidden="true"
      />
    </aside>

    <!-- ───────── Form panel ───────── -->
    <main class="flex flex-1 flex-col px-5 py-6 sm:px-10">
      <!-- compact brand bar for small screens -->
      <div class="flex items-center justify-between lg:hidden">
        <router-link :to="backLink" class="inline-flex items-center gap-2 text-sm font-medium text-fikr-ink-muted hover:text-fikr-ink">
          <svg class="h-4 w-4 rtl:rotate-180" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
            <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7" />
          </svg>
          {{ $t('login.back') }}
        </router-link>
        <span class="text-base font-bold tracking-[0.04em] text-navy-800" dir="ltr">FIKR</span>
      </div>

      <div class="flex flex-1 items-center justify-center">
        <div class="w-full max-w-[400px]">
          <!-- logo card -->
          <div class="mx-auto flex h-[170px] w-[170px] items-center justify-center rounded-[22px] bg-fikr-parchment sm:h-[190px] sm:w-[190px]">
            <img
              v-if="isSchoolLogin"
              :src="schoolLogo"
              :alt="displayTitle"
              class="h-[140px] w-[140px] rounded-2xl object-contain"
            />
            <img
              v-else
              src="/fikr-logo.png?v=4"
              :alt="$t('forSchools.logoAlt')"
              class="h-[150px] w-[150px] object-contain"
            />
          </div>

          <div class="mt-6 text-center">
            <h1 class="text-[30px] font-bold tracking-[-0.01em] text-fikr-ink sm:text-[34px]">
              {{ $t('login.title') }}
            </h1>
            <p class="mt-1 text-base text-fikr-ink-soft">{{ formSubtitle }}</p>
          </div>

          <form class="mt-7 space-y-3" @submit.prevent="handleLogin">
            <div>
              <label for="email" class="sr-only">{{ $t('login.email') }}</label>
              <input
                id="email"
                v-model="email"
                type="email"
                required
                autocomplete="email"
                class="fk-input rounded-xl px-4 py-3.5 text-base"
                :placeholder="$t('login.emailPlaceholder')"
              />
            </div>

            <div class="relative">
              <label for="password" class="sr-only">{{ $t('login.password') }}</label>
              <input
                id="password"
                v-model="password"
                :type="showPassword ? 'text' : 'password'"
                required
                autocomplete="current-password"
                class="fk-input rounded-xl px-4 py-3.5 pe-12 text-base tracking-[0.15em]"
                :placeholder="$t('login.passwordPlaceholder')"
              />
              <button
                type="button"
                class="absolute inset-y-0 end-0 flex items-center pe-4 text-fikr-ink-soft hover:text-fikr-ink"
                :aria-label="$t('login.password')"
                @click="showPassword = !showPassword"
              >
                <svg v-if="showPassword" class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                </svg>
                <svg v-else class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.878 9.878L3 3m6.878 6.878L21 21" />
                </svg>
              </button>
            </div>

            <!-- role picker (2 × 2) -->
            <fieldset class="pt-2">
              <legend class="mb-2 text-sm font-medium text-fikr-ink">{{ $t('login.previewAs') }}</legend>
              <div class="grid grid-cols-2 gap-3">
                <button
                  v-for="r in roles"
                  :key="r.value"
                  type="button"
                  class="rounded-xl border px-3 py-3 text-sm font-medium transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-500/40 focus-visible:ring-offset-2 active:scale-[0.98]"
                  :class="
                    selectedRole === r.value
                      ? 'border-primary-500 bg-primary-500 text-white'
                      : 'border-fikr-hairline bg-white text-fikr-ink hover:border-fikr-outline'
                  "
                  :aria-pressed="selectedRole === r.value"
                  @click="selectedRole = r.value"
                >
                  {{ $t(r.labelKey) }}
                </button>
              </div>
            </fieldset>

            <p v-if="error" class="fk-alert fk-alert--error">{{ error }}</p>

            <button
              type="submit"
              :disabled="loading"
              class="fk-btn fk-btn--primary mt-3 w-full rounded-xl py-3.5 text-base"
            >
              <template v-if="loading">
                <FikrLoader v-if="!isSchoolLogin" size="xs" />
                <svg v-else class="h-5 w-5 animate-spin text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true">
                  <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                  <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                {{ $t('login.signingIn') }}
              </template>
              <template v-else>{{ $t('login.continue') }}</template>
            </button>

            <div class="flex items-center justify-between pt-3">
              <button type="button" class="text-sm font-medium text-primary-600 hover:text-primary-700 hover:underline">
                {{ $t('login.forgotPassword') }}
              </button>
              <button
                type="button"
                class="fk-btn fk-btn--pearl fk-btn--tool px-4 py-2 text-sm font-medium"
                @click="toggleLanguage"
              >
                {{ $t('login.switchLanguage') }}
              </button>
            </div>
          </form>

          <p v-if="!isSchoolLogin" class="mt-6 text-center text-xs text-fikr-ink-soft">
            <router-link to="/subscribe" class="font-semibold text-primary-600 hover:underline">
              {{ $t('login.subscribeSchool') }}
            </router-link>
          </p>
        </div>
      </div>

      <p class="mt-6 text-center text-xs text-fikr-ink-soft lg:hidden">{{ $t('login.footerBrand') }}</p>
    </main>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import { useRoute, useRouter } from 'vue-router'
import FikrLoader from '@/components/FikrLoader.vue'
import { authService } from '@/services'
import { schoolLandingService } from '@/services/school-landing.service'

type LoginRole = 'admin' | 'teacher' | 'parent' | 'student'

const { locale, t } = useI18n()
const router = useRouter()
const route = useRoute()

const email = ref('')
const password = ref('')
const showPassword = ref(false)
const loading = ref(false)
const error = ref('')
const schoolBrand = ref('')
const schoolLogo = ref('/zlogo.jpeg')
const selectedRole = ref<LoginRole>(
  (localStorage.getItem('login.previewRole') as LoginRole | null) ?? 'admin',
)

const roles: { value: LoginRole; labelKey: string }[] = [
  { value: 'admin', labelKey: 'login.roleAdmin' },
  { value: 'teacher', labelKey: 'login.roleTeacher' },
  { value: 'parent', labelKey: 'login.roleParent' },
  { value: 'student', labelKey: 'login.roleStudent' },
]

const isRTL = computed(() => locale.value === 'ar')

const schoolSlug = computed(() => {
  const slug = route.params.slug
  return typeof slug === 'string' && slug.trim() ? slug.trim() : ''
})

const isSchoolLogin = computed(() => route.name === 'school-login' && !!schoolSlug.value)

const backLink = computed(() => (isSchoolLogin.value ? `/s/${schoolSlug.value}` : '/'))

const displayTitle = computed(() => {
  if (isSchoolLogin.value) return schoolBrand.value || t('hero.brandName')
  return t('forSchools.brand')
})

const formSubtitle = computed(() =>
  isSchoolLogin.value ? displayTitle.value : t('login.platformSubtitle'),
)

const heroSubtitle = computed(() =>
  isSchoolLogin.value
    ? t('login.heroSubtitleSchool', { school: displayTitle.value })
    : t('login.heroSubtitlePlatform'),
)

function toggleLanguage() {
  const next = locale.value === 'ar' ? 'en' : 'ar'
  locale.value = next
  localStorage.setItem('language', next)
  document.documentElement.dir = next === 'ar' ? 'rtl' : 'ltr'
  document.documentElement.lang = next === 'ar' ? 'ar-OM' : next
}

onMounted(async () => {
  document.documentElement.dir = isRTL.value ? 'rtl' : 'ltr'
  document.documentElement.lang = locale.value === 'ar' ? 'ar-OM' : locale.value
  if (!isSchoolLogin.value) return
  try {
    const cms = await schoolLandingService.getPublicBySlug(schoolSlug.value)
    schoolBrand.value =
      locale.value === 'ar'
        ? cms.brand_name_ar || cms.brand_name_en || ''
        : cms.brand_name_en || cms.brand_name_ar || ''
    if (cms.logo_url) schoolLogo.value = cms.logo_url
  } catch {
    schoolBrand.value = t('hero.brandName')
    schoolLogo.value = '/zlogo.jpeg'
  }
})

const handleLogin = async () => {
  error.value = ''
  if (!email.value || !password.value) {
    error.value = t('login.fillRequired')
    return
  }

  try {
    loading.value = true
    localStorage.setItem('login.previewRole', selectedRole.value)
    const response = await authService.login({
      email: email.value,
      password: password.value,
    })

    const user = response.user as {
      role?: string
      isSuperAdmin?: boolean
      isSystemUser?: boolean
    }
    if (user?.isSuperAdmin || user?.isSystemUser) {
      router.push('/platform/schools')
    } else if (user?.role === 'parent') {
      router.push('/parent/dashboard')
    } else {
      router.push('/dashboard')
    }
  } catch (e: unknown) {
    const ax = e as { response?: { data?: { message?: string | string[] } }; message?: string }
    const m = ax.response?.data?.message
    error.value = Array.isArray(m) ? m.join(', ') : m || ax.message || t('login.failed')
  } finally {
    loading.value = false
  }
}
</script>
