<template>
  <DashboardLayout>
    <div class="fk-page" :dir="isRTL ? 'rtl' : 'ltr'">
      <FikrPageHeader
        :eyebrow="$t('systemSettings.eyebrow')"
        :title="$t('systemSettings.gradesManagement')"
        :subtitle="$t('systemSettings.gradesPageIntro')"
      >
        <template #actions>
          <button type="button" class="fk-btn fk-btn--primary" @click="openAddModal">
            <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
            </svg>
            {{ $t('systemSettings.addGrade') }}
          </button>
        </template>
      </FikrPageHeader>

      <section class="fk-card">
        <header class="fk-card__header">
          <div class="min-w-0">
            <h2 class="fk-card__title">{{ $t('systemSettings.gradesManagement') }}</h2>
            <p class="fk-card__meta">{{ grades.length }}</p>
          </div>
        </header>

        <div v-if="grades.length" class="overflow-visible">
          <table class="fk-table">
            <thead>
              <tr>
                <th>{{ $t('common.name') }}</th>
                <th>{{ $t('systemSettings.gradeCode') }}</th>
                <th>{{ $t('systemSettings.description') }}</th>
                <th>{{ $t('common.status') }}</th>
                <th class="text-end">{{ $t('common.actions') }}</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="grade in grades" :key="grade.id">
                <td>
                  <div class="flex items-center gap-3">
                    <span class="fk-monogram fk-monogram--navy text-xs">{{ (grade.code || '?').slice(0, 3) }}</span>
                    <div class="min-w-0">
                      <div class="font-medium text-fikr-ink">{{ isRTL ? grade.nameAr : grade.nameEn }}</div>
                      <div class="mt-0.5 text-xs text-fikr-ink-soft">{{ isRTL ? grade.nameEn : grade.nameAr }}</div>
                    </div>
                  </div>
                </td>
                <td><span class="fk-chip fk-chip--outline font-mono" dir="ltr">{{ grade.code }}</span></td>
                <td class="text-fikr-ink-muted">{{ grade.description || '—' }}</td>
                <td>
                  <span class="fk-chip" :class="grade.isActive ? 'fk-chip--green' : 'fk-chip--neutral'">
                    {{ grade.isActive ? $t('settings.active') : $t('settings.inactive') }}
                  </span>
                </td>
                <td class="text-end">
                  <RowActionsMenu
                    :open="activeMenuId === grade.id"
                    @toggle="toggleMenu(grade.id)"
                  >
                    <RowActionsItem icon="edit" @click="openEditModal(grade)">
                      {{ $t('common.edit') }}
                    </RowActionsItem>
                    <RowActionsItem
                      :icon="grade.isActive ? 'archive' : 'activate'"
                      @click="toggleGradeStatus(grade)"
                    >
                      {{ grade.isActive ? $t('groupManagement.deactivate') : $t('groupManagement.activate') }}
                    </RowActionsItem>
                    <RowActionsItem icon="delete" danger @click="deleteGrade(grade)">
                      {{ $t('common.delete') }}
                    </RowActionsItem>
                  </RowActionsMenu>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <div v-else class="p-5 sm:p-6">
          <div class="fk-empty">
            <div class="fk-empty__icon">
              <svg class="h-7 w-7" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
              </svg>
            </div>
            <h3 class="fk-empty__title">{{ $t('systemSettings.noGradesFound') }}</h3>
            <p class="fk-empty__desc">{{ $t('systemSettings.noGradesDescription') }}</p>
            <button type="button" class="fk-btn fk-btn--primary mt-5" @click="openAddModal">
              {{ $t('systemSettings.createFirstGrade') }}
            </button>
          </div>
        </div>
      </section>

      <GradeModal
        :show="showGradeModal"
        :grade="editingGrade"
        @close="closeGradeModal"
        @save="saveGrade"
      />
    </div>
  </DashboardLayout>
</template>

<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import DashboardLayout from '@/layouts/DashboardLayout.vue'
import FikrPageHeader from '@/components/FikrPageHeader.vue'
import GradeModal from '@/components/GradeModal.vue'
import RowActionsMenu from '@/components/RowActionsMenu.vue'
import RowActionsItem from '@/components/RowActionsItem.vue'
import { gradeService, type CreateGradeData, type Grade } from '@/services/grade.service'

const { locale, t } = useI18n()
const isRTL = computed(() => locale.value === 'ar')

const grades = ref<Grade[]>([])
const showGradeModal = ref(false)
const editingGrade = ref<Grade | null>(null)
const activeMenuId = ref<string | null>(null)

function toggleMenu(id: string) {
  activeMenuId.value = activeMenuId.value === id ? null : id
}

function handleClickOutside() {
  activeMenuId.value = null
}

function openAddModal() {
  editingGrade.value = null
  showGradeModal.value = true
}

function openEditModal(grade: Grade) {
  activeMenuId.value = null
  editingGrade.value = { ...grade }
  showGradeModal.value = true
}

function closeGradeModal() {
  showGradeModal.value = false
  editingGrade.value = null
}

async function loadGrades() {
  try {
    grades.value = await gradeService.getAll()
  } catch (error) {
    console.error('Error loading grades:', error)
  }
}

async function saveGrade(data: CreateGradeData) {
  try {
    if (editingGrade.value) {
      await gradeService.update(editingGrade.value.id, {
        nameEn: data.nameEn,
        nameAr: data.nameAr,
        code: data.code,
        description: data.description,
      })
    } else {
      const maxOrder = grades.value.length > 0
        ? Math.max(...grades.value.map((g) => g.displayOrder))
        : 0
      await gradeService.create({
        ...data,
        displayOrder: maxOrder + 1,
      })
    }
    closeGradeModal()
    await loadGrades()
  } catch (error) {
    console.error('Error saving grade:', error)
    alert(t('systemSettings.gradeSaveError'))
  }
}

async function toggleGradeStatus(grade: Grade) {
  activeMenuId.value = null
  try {
    await gradeService.update(grade.id, { isActive: !grade.isActive })
    await loadGrades()
  } catch (error) {
    console.error('Error toggling grade status:', error)
    alert(t('systemSettings.gradeSaveError'))
  }
}

async function deleteGrade(grade: Grade) {
  activeMenuId.value = null
  const name = isRTL.value ? grade.nameAr : grade.nameEn
  if (!confirm(t('systemSettings.confirmDeleteGrade', { name }))) return
  try {
    await gradeService.remove(grade.id)
    await loadGrades()
  } catch (error) {
    console.error('Error deleting grade:', error)
    alert(t('systemSettings.gradeSaveError'))
  }
}

onMounted(() => {
  document.addEventListener('click', handleClickOutside)
  void loadGrades()
})

onUnmounted(() => {
  document.removeEventListener('click', handleClickOutside)
})
</script>
