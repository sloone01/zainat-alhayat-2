<template>
  <DashboardLayout>
    <div class="space-y-6 pb-10" :dir="isRTL ? 'rtl' : 'ltr'">
      <section class="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-800 via-primary-800 to-teal-800 p-6 text-white shadow-xl sm:p-8">
        <div class="pointer-events-none absolute -end-10 -top-10 h-40 w-40 rounded-full bg-white/10 blur-2xl" aria-hidden="true" />
        <div class="relative">
          <h1 class="text-2xl font-bold tracking-tight sm:text-3xl">{{ $t('dashboard.reports') }}</h1>
          <p class="mt-2 max-w-2xl text-sm text-slate-200/95">{{ $t('reports.description') }}</p>
        </div>
      </section>

      <div class="grid grid-cols-1 gap-6 md:grid-cols-2">
        <div class="overflow-hidden rounded-2xl border border-gray-200/80 bg-white shadow-sm">
          <div class="border-b border-gray-100 bg-gradient-to-r from-primary-50/80 to-white px-6 py-4">
            <h2 class="text-lg font-semibold text-gray-900">{{ $t('reports.academicReports') }}</h2>
            <p class="mt-0.5 text-xs text-gray-500">{{ $t('reports.gradedReportsHint') }}</p>
          </div>
          <div class="space-y-3 p-6">
            <button
              v-for="report in gradedReports"
              :key="report.id"
              type="button"
              class="w-full rounded-xl border border-gray-200 p-4 text-start transition hover:border-primary-200 hover:bg-primary-50/30"
              @click="openReport(report.route)"
            >
              <div class="font-semibold text-gray-900">{{ report.title }}</div>
              <div class="mt-1 text-sm text-gray-600">{{ report.description }}</div>
            </button>
          </div>
        </div>

        <div class="overflow-hidden rounded-2xl border border-gray-200/80 bg-white shadow-sm">
          <div class="border-b border-gray-100 bg-gradient-to-r from-amber-50/80 to-white px-6 py-4">
            <h2 class="text-lg font-semibold text-gray-900">{{ $t('reports.feeReports') }}</h2>
            <p class="mt-0.5 text-xs text-gray-500">{{ $t('reports.feeReportsHint') }}</p>
          </div>
          <div class="space-y-3 p-6">
            <button
              type="button"
              class="w-full rounded-xl border border-gray-200 p-4 text-start transition hover:border-primary-200 hover:bg-primary-50/30"
              @click="openReport('/reports/fees/due-installments')"
            >
              <div class="font-semibold text-gray-900">{{ $t('reports.dueFeesTitle') }}</div>
              <div class="mt-1 text-sm text-gray-600">{{ $t('reports.dueFeesDesc') }}</div>
            </button>
          </div>
        </div>
      </div>
    </div>
  </DashboardLayout>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useI18n } from 'vue-i18n'
import { useRouter } from 'vue-router'
import DashboardLayout from '@/layouts/DashboardLayout.vue'

const { t, locale } = useI18n()
const router = useRouter()
const isRTL = computed(() => locale.value === 'ar')

const gradedReports = computed(() => [
  {
    id: 'graded-class',
    title: t('reports.gradedClassTitle'),
    description: t('reports.gradedClassDesc'),
    route: '/reports/graded-marks/class',
  },
  {
    id: 'graded-student',
    title: t('reports.gradedStudentTitle'),
    description: t('reports.gradedStudentDesc'),
    route: '/reports/graded-marks/student',
  },
])

function openReport(route: string) {
  void router.push(route)
}
</script>
